# Equity currencies for residential cooling allocation during heat waves

Code and derived data for the manuscript "Equity metrics for allocating scarce
residential cooling during heat waves: evidence from three US cities".

## Requirements

Python 3.11 or later with

    numpy>=2.2  pandas>=2.2  scipy>=1.13  matplotlib>=3.9  pythermalcomfort==4.4.2

## Input data (public, not redistributed here)

1. ResStock housing characteristics (NREL). Clone the repository and check out
   the commit used in the study:

       git clone https://github.com/NREL/resstock data/resstock
       git -C data/resstock checkout 33433157aa52d1a97f35b9640bdf7a2c46f5d908

   The sampler reads `data/resstock/project_national/housing_characteristics`
   (override with the environment variable `RESSTOCK_HC`).

2. RECS 2020 public-use microdata, version 7 (US EIA). Save as
   `data/recs2020_public_v7.csv`.

3. Weather. Hourly ASOS observations (Iowa Environmental Mesonet) and hourly
   NASA POWER global horizontal irradiance for the four 2023 episodes are
   included in `data/wx_observed_2023.py`.

## Pipeline

    python src/forcing.py              # 96-h forcing per episode   -> work/forcing_*.npz
    python src/build_stock.py --n 300  # stocks + linked occupants -> work/stock_*.npz
    python src/baseline_core.py        # usual core temperature    -> work/core_base_*.npy
    ./run_all.sh                       # coupled simulations       -> work/curves_*.npz
    python src/analyse.py --runs HOU-A HOU-B PHX CHI HOU-A-UQ HOU-A-FAN PHX-FAN --boot 50
    python src/recs_evidence.py        # survey evidence           -> out/recs_evidence.json
    python src/fig_episodes.py
    python src/fig_results.py
    python src/make_tables.py          # LaTeX tables and numbers

Each coupled simulation of 300 dwellings at nine cooling levels takes about
20 minutes on 8 cores (`--workers` sets the number of processes).

## Runs

| Run        | Stock   | Episode               | Variant                           |
|------------|---------|-----------------------|-----------------------------------|
| HOU-A      | Houston | 20-22 Aug 2023        | base                              |
| HOU-B      | Houston | 25-27 Aug 2023        | base                              |
| PHX        | Phoenix | 18-20 Jul 2023        | base                              |
| CHI        | Chicago | 22-24 Aug 2023        | base                              |
| HOU-A-UQ   | Houston | 20-22 Aug 2023        | building-parameter perturbation   |
| HOU-A-FAN  | Houston | 20-22 Aug 2023        | electric fan use above 26 C       |
| PHX-FAN    | Phoenix | 18-20 Jul 2023        | electric fan use above 26 C       |

## Derived data included

`work/` holds the sampled stocks with linked occupants, the forcing series, the
usual core temperatures and the simulated response curves, so that the
allocation analysis, tables and figures can be reproduced without re-running
the simulations.
