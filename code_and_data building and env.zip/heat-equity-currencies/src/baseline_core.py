"""
Each occupant's usual core temperature: chest core temperature at steady state
in their own conditioned home (constant air temperature equal to their reported
cooling setpoint, 60 % relative humidity (the indoor humidity cap applied when an air conditioner runs), still air), after 48 h.

Heat strain is then measured as the rise in core temperature above this
person-specific baseline, rather than above a fixed 37 C threshold that lies
below some individuals' normal resting chest core temperature in the model.
"""
import warnings
import numpy as np
from multiprocessing import Pool
from pathlib import Path
warnings.filterwarnings("ignore")
ROOT = Path(__file__).resolve().parents[1]

def one(args):
    from pythermalcomfort.models import JOS3
    import jos3 as up
    h, w, f, a, s, tset = args
    m = JOS3(height=h, weight=w, fat=f, age=a, sex=s)
    sp = float(np.mean(m.cr_set_point))
    if (not np.isfinite(sp)) or sp < 35.5:
        u = up.JOS3(height=h, weight=w, fat=f, age=a, sex=s)
        m.cr_set_point = np.array(u.setpt_cr, float).copy()
        m.sk_set_point = np.array(u.setpt_sk, float).copy()
        m.t_body = np.array(JOS3().t_body, float).copy()
    m.clo, m.par, m.v, m.to, m.rh = 0.35, 1.1, 0.15, float(tset), 60.0
    c = []
    for k in range(48):
        m.simulate(times=3, dtime=1200, output=False)
        if k >= 24: c.append(float(m.t_core[2]))
    return float(np.mean(c))

if __name__ == "__main__":
    for city in ["HOU", "PHX", "CHI"]:
        P = np.load(ROOT / "work" / f"stock_{city}.npz", allow_pickle=True)
        args = [(float(P["height"][i]), float(P["weight"][i]), float(P["fat"][i]), int(P["age"][i]),
                 str(P["sex"][i]), float(P["Tset"][i])) for i in range(len(P["UA"]))]
        with Pool(2) as pool:
            base = np.array(pool.map(one, args, chunksize=10))
        np.save(ROOT / "work" / f"core_base_{city}.npy", base)
        print(city, "baseline chest core: median %.2f, range %.2f-%.2f" % (np.median(base), base.min(), base.max()), flush=True)
