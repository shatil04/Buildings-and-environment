"""Write LaTeX tables and a macro file of key numbers from the analysis outputs."""
import json, numpy as np
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]; OUT = ROOT / "out"; MS = ROOT / "ms"
RUNS = [("HOU-A", "Houston A"), ("HOU-B", "Houston B"), ("PHX", "Phoenix"), ("CHI", "Chicago"),
        ("HOU-A-UQ", "Houston A, uncertainty"), ("HOU-A-FAN", "Houston A, fan use"),
        ("PHX-FAN", "Phoenix, fan use")]
A = {r: json.load(open(OUT / f"analysis_{r}.json")) for r, _ in RUNS if (OUT / f"analysis_{r}.json").exists()}
RUNS = [(r, l) for r, l in RUNS if r in A]
BASE = [r for r, _ in RUNS if r in ("HOU-A", "HOU-B", "PHX", "CHI")]
recs = json.load(open(OUT / "recs_evidence.json"))
CUR = ["M1", "M2", "M3", "M4"]
def f(x, d=2):
    if x is None: return "--"
    v = f"{x:.{d}f}"
    if float(v) == 0: v = v.lstrip("-")
    return "$-$" + v[1:] if v.startswith("-") else v
def p(x, d=0):
    if x is None: return "--"
    v = f"{100*x:.{d}f}"
    if float(v) == 0: v = v.lstrip("-")
    return "$-$" + v[1:] if v.startswith("-") else v
def ci(bo, k, d=0): return f"{p(bo[k]['mean'],d)} [{p(bo[k]['lo'],d)}, {p(bo[k]['hi'],d)}]"

# ---- Table: agreement ----
L = []
for r, lab in RUNS:
    b = A[r]["base"]; bo = A[r]["boot"]; pr = ["M1-M2", "M1-M3", "M1-M4", "M3-M4"]
    L.append(f"{lab} & " + " & ".join(f(b['rho'][k]) for k in pr) +
             f" & {p(b['mig']['M1-M3'])} & {p(b['mig']['M1-M4'])} \\\\")
    L.append("& " + " & ".join(f"{{\\footnotesize[{f(bo['rho_'+k]['lo'])}, {f(bo['rho_'+k]['hi'])}]}}" for k in pr) + " & & \\\\[2pt]")
(MS / "tab_agree_rows.tex").write_text("\n".join(L) + "\n")

# ---- Table: strain by group and currency ----
L = []
for r, lab in RUNS:
    o = A[r]["base"]["out"]; u = A[r]["unmit_groups"]["SR"]
    for g, gl in [("lowinc", "Low income"), ("age65", "Aged 65+"), ("all", "All homes (mean)")]:
        first = lab if g == "lowinc" else ""
        L.append(f"{first} & {gl} & {f(u[g],1)} & " + " & ".join(f(o[c]['SR'][g], 1) for c in CUR) + " \\\\")
    L.append("\\addlinespace[2pt]")
(MS / "tab_strain_rows.tex").write_text("\n".join(L[:-1]) + "\n")

# ---- Table: bootstrap gains ----
L = []
ks = ["gain_M3_M1_lowinc", "gain_M4_M1_lowinc", "gain_M3_M1_age65", "gain_M4_M1_age65", "gain_M4_M1_all"]
for r, lab in RUNS:
    bo = A[r]["boot"]
    L.append(f"{lab} & " + " & ".join(p(bo[k]['mean']) for k in ks) + " \\\\")
    L.append("& " + " & ".join(f"{{\\footnotesize[{p(bo[k]['lo'])}, {p(bo[k]['hi'])}]}}" for k in ks) + " \\\\[2pt]")
(MS / "tab_gain_rows.tex").write_text("\n".join(L) + "\n")

# ---- Table: other health metrics, base episodes ----
H = [("H38", "Hours core $\\ge$\\SI{38}{\\degree C}", 2), ("PK", "Peak core (\\si{\\degree C})", 2),
     ("SW", "Sweat loss (\\% body mass d$^{-1}$)", 2), ("HI", "Heat-index danger hours", 1)]
L = []
for r, lab in RUNS:
    if r not in BASE: continue
    o = A[r]["base"]["out"]
    L.append(f"\\multicolumn{{9}}{{@{{}}l}}{{\\emph{{{lab}}}}} \\\\")
    for k, name, d in H:
        L.append(f"\\quad {name} & " + " & ".join(f(o[c][k]['lowinc'], d) for c in CUR) + " & "
                 + " & ".join(f(o[c][k]['all'], d) for c in CUR) + " \\\\")
(MS / "tab_health_rows.tex").write_text("\n".join(L) + "\n")

# ---- Table: thresholds ----
L = []
for r, lab in RUNS:
    if r not in BASE: continue
    for sk, sl in [("SR05", "usual + \\SI{0.5}{\\degree C}"), ("S38", "fixed \\SI{38}{\\degree C}")]:
        t = A[r]["threshold"][sk]
        L.append(f"{lab if sk=='SR05' else ''} & {sl} & {f(t['rho']['M1-M3'])} & {f(t['rho']['M1-M4'])} & "
                 + " & ".join(f(t['lowinc'][c], 2) for c in CUR) + " \\\\")
(MS / "tab_thr_rows.tex").write_text("\n".join(L) + "\n")

# ---- Table: energy plausibility ----
st = {"HOU-A": "TX", "HOU-B": "TX", "PHX": "AZ", "CHI": "IL"}
L = []
for r, lab in RUNS:
    if r not in st: continue
    F = np.load(ROOT / "work" / f"forcing_{r}.npz"); T = F["T_out"][24:]
    cdd = sum(max(np.mean(T[24*d:24*d+24]) * 9 / 5 + 32 - 65, 0) for d in range(3))
    q25, med, q75 = recs["kwh_per_cdd65"][st[r]]["q25_med_q75"]
    D = np.load(ROOT / "work" / f"curves_{r}.npz"); E = D["E"][:, -1]; Ec = E[E > 0] / 3.0
    L.append(f"{lab} & {cdd:.0f} & {med*cdd:.0f} [{q25*cdd:.0f}--{q75*cdd:.0f}] & "
             f"{np.median(Ec):.0f} [{np.quantile(Ec,.25):.0f}--{np.quantile(Ec,.75):.0f}] \\\\")
(MS / "tab_energy_rows.tex").write_text("\n".join(L) + "\n")

# ---- Appendix sweep ----
L = []
for r, lab in RUNS:
    if r not in BASE: continue
    L.append(f"\\midrule\\multicolumn{{6}}{{@{{}}l}}{{\\emph{{{lab}}}: mean strain of low-income households (\\si{{\\degree C}}\\,h)}} \\\\")
    for row in A[r]["sweep"]:
        L.append(f"{row['eta']:.1f} & {int(100*row['b'])}\\% & " + " & ".join(f(row[c]['lowinc'], 1) for c in CUR) + " \\\\")
(MS / "tab_sweep_rows.tex").write_text("\n".join(L) + "\n")

# ---- RECS table ----
L = []
lab = {"0-100%": "Below 100\\,\\%", "100-150%": "100--150\\,\\%", "150-200%": "150--200\\,\\%",
       "200-300%": "200--300\\,\\%", "300-400%": "300--400\\,\\%", "400%+": "Above 400\\,\\%"}
for k in ["0-100%", "100-150%", "150-200%", "200-300%", "300-400%", "400%+"]:
    h = recs["HOTMA_by_FPL_US"][k]; a = recs["NOAC_by_FPL_US"][k]
    L.append(f"{lab[k]} & {h[3]:,} & {h[0]:.2f} [{h[1]:.2f}, {h[2]:.2f}] & {a[0]:.1f} [{a[1]:.1f}, {a[2]:.1f}] \\\\")
L.append("\\midrule")
for k in ["18-44", "45-64", "65-74", "75+"]:
    h = recs["HOTMA_by_age_US"][k]
    L.append(f"Householder aged {k.replace('-','--')} & {h[3]:,} & {h[0]:.2f} [{h[1]:.2f}, {h[2]:.2f}] & -- \\\\")
(MS / "tab_recs_rows.tex").write_text("\n".join(L) + "\n")

# ---- macros ----
M = []
def mac(name, val): M.append(f"\\newcommand{{\\{name}}}{{{val}}}")
tag = {"HOU-A": "HouA", "HOU-B": "HouB", "PHX": "Phx", "CHI": "Chi", "HOU-A-UQ": "HouAUq",
       "HOU-A-FAN": "HouAFan", "PHX-FAN": "PhxFan"}
for r, _ in RUNS:
    a = A[r]; b = a["base"]; o = b["out"]; bo = a["boot"]; t = tag[r]
    mac(f"rhoThree{t}", f(b["rho"]["M1-M3"])); mac(f"rhoFour{t}", f(b["rho"]["M1-M4"]))
    mac(f"migThree{t}", p(b["mig"]["M1-M3"])); mac(f"migFour{t}", p(b["mig"]["M1-M4"]))
    for new in ["M3", "M4"]:
        for g in ["lowinc", "age65", "all", "median"]:
            k = f"gain_{new}_M1_{g}"
            nm = "g" + {"M3": "Three", "M4": "Four"}[new] + {"lowinc": "Li", "age65": "Old", "all": "All", "median": "Med"}[g] + t
            mac(nm, p(bo[k]["mean"])); mac(nm + "lo", p(bo[k]["lo"])); mac(nm + "hi", p(bo[k]["hi"]))
    pe = a["penalty"]["M1"]; mac(f"penOne{t}", p(pe) if pe is not None else "more than 120")
    mac(f"unr{t}", a["unreachable"]); mac(f"guard{t}", a["guard"]); mac(f"mono{t}", a["monotone_1pct"])
    mac(f"unmed{t}", f(a["unmitigated"]["SR"]["median"], 1)); mac(f"fullmed{t}", f(a["fullcool"]["SR"]["median"], 1))
    mac(f"hiunmed{t}", f(a["unmitigated"]["HI"]["median"], 0))
    mac(f"hiOne{t}", f(o["M1"]["HI"]["all"], 1)); mac(f"hiFour{t}", f(o["M4"]["HI"]["all"], 1))
h = recs["HOTMA_by_FPL_US"]
mac("hotmaPov", f"{h['0-100%'][0]:.1f}"); mac("hotmaRich", f"{h['400%+'][0]:.1f}")
mac("noacPov", f"{recs['NOAC_by_FPL_US']['0-100%'][0]:.0f}"); mac("noacRich", f"{recs['NOAC_by_FPL_US']['400%+'][0]:.0f}")
for base, fan, nm in [("PHX", "PHX-FAN", "Phx"), ("HOU-A", "HOU-A-FAN", "HouA")]:
    if base in A and fan in A:
        u0 = A[base]["unmitigated"]["SR"]["median"]; u1 = A[fan]["unmitigated"]["SR"]["median"]
        word = "increased" if u1 > u0 else "reduced"
        mac(f"fan{nm}Direction", f"{word} the median unmitigated strain from {u0:.1f} to {u1:.1f}\\,\\si{{\\degree C}}\\,h")
        mac(f"fanUnmed{nm}", f"{u1:.1f}"); mac(f"noFanUnmed{nm}", f"{u0:.1f}")
        mac(f"fanSw{nm}", f"{A[fan]['unmitigated']['SW']['median']:.1f}"); mac(f"noFanSw{nm}", f"{A[base]['unmitigated']['SW']['median']:.1f}")
        mac(f"fanOld{nm}", f"{A[fan]['unmit_groups']['SR']['age65']:.1f}"); mac(f"noFanOld{nm}", f"{A[base]['unmit_groups']['SR']['age65']:.1f}")
for c in ["HOU", "PHX", "CHI"]:
    P = np.load(ROOT / "work" / f"stock_{c}.npz", allow_pickle=True)
    M.append(f"\\newcommand{{\\occ{c.lower()}}}{{{100*np.mean(P['match']==0):.0f}\\,\\%}}")
(MS / "numbers_rev.tex").write_text("\n".join(M) + "\n")
print("tables and macros written for", [r for r, _ in RUNS])
