"""
Empirical evidence from RECS 2020 used to ground and check the simulation.

1. Heat-related medical attention (HOTMA) and lack of air conditioning by
   poverty band and householder age, nationally and in the three study states.
2. Plausibility of simulated cooling energy: reported annual cooling
   electricity (KWHCOL) scaled by cooling degree days, compared with the
   simulated unconstrained cooling demand per dwelling during each episode.

Weighted estimates use the final weight NWEIGHT. Uncertainty is a 95%
interval from 400 household-level bootstrap resamples of the weighted estimate,
which is conservative relative to replicate-weight variance for rare outcomes.
"""
import json
import numpy as np
import pandas as pd
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
FPL_BINS = ["0-100%", "100-150%", "150-200%", "200-300%", "300-400%", "400%+"]
MID = {1: 2500, 2: 6250, 3: 8750, 4: 11250, 5: 13750, 6: 17500, 7: 22500, 8: 27500,
       9: 32500, 10: 37500, 11: 45000, 12: 55000, 13: 67500, 14: 87500, 15: 125000, 16: 200000}

def load():
    df = pd.read_csv(ROOT / "data" / "recs2020_public_v7.csv", low_memory=False)
    guide = 12760 + 4480 * (df.NHSLDMEM.clip(lower=1) - 1)
    pct = 100 * df.MONEYPY.map(MID) / guide
    df["FPL"] = pd.cut(pct, [-1, 100, 150, 200, 300, 400, 1e9], labels=FPL_BINS).astype(str)
    df["AGEG"] = pd.cut(df.HHAGE, [0, 44, 64, 74, 200], labels=["18-44", "45-64", "65-74", "75+"]).astype(str)
    df["NOAC"] = (df.AIRCOND == 0).astype(float)
    return df

def wmean(d, col):
    """Weighted mean with a bootstrap 95% interval."""
    w = d.NWEIGHT.values; y = d[col].values.astype(float)
    est = (w * y).sum() / w.sum()
    r = np.random.default_rng(5); n = len(d); b = []
    for _ in range(400):
        ix = r.integers(0, n, n); b.append((w[ix] * y[ix]).sum() / w[ix].sum())
    lo, hi = np.percentile(b, [2.5, 97.5])
    return est, (lo, hi), n

def table(df, by, col):
    out = {}
    for g, d in df.groupby(by):
        if len(d) >= 30:
            e, (lo, hi), n = wmean(d, col)
            out[str(g)] = [round(100 * e, 2), round(100 * lo, 2), round(100 * hi, 2), int(n)]
    return out

if __name__ == "__main__":
    df = load()
    res = {"n": int(len(df))}
    res["HOTMA_by_FPL_US"] = table(df, "FPL", "HOTMA")
    res["HOTMA_by_age_US"] = table(df, "AGEG", "HOTMA")
    res["NOAC_by_FPL_US"] = table(df, "FPL", "NOAC")
    st = df[df.state_postal.isin(["TX", "AZ", "IL"])]
    res["HOTMA_by_state"] = table(st, "state_postal", "HOTMA")
    res["NOAC_by_state_FPL"] = {s: table(st[st.state_postal == s], "FPL", "NOAC") for s in ["TX", "AZ", "IL"]}
    e, (lo, hi), n = wmean(df, "HOTMA"); res["HOTMA_US"] = [round(100*e, 2), round(100*lo, 2), round(100*hi, 2), n]
    # poor (<150% FPL) vs not
    df["POOR"] = df.FPL.isin(["0-100%", "100-150%"])
    res["HOTMA_poor_vs_not"] = table(df, "POOR", "HOTMA")
    # cooling-energy plausibility: kWh per cooling degree day, cooled homes only
    c = df[(df.AIRCOND == 1) & (df.CDD65 > 0) & (df.KWHCOL > 0)].copy()
    c["kwh_per_cdd"] = c.KWHCOL / c.CDD65
    res["kwh_per_cdd65"] = {}
    for s in ["TX", "AZ", "IL"]:
        d = c[c.state_postal == s]
        q = np.quantile(d.kwh_per_cdd, [0.25, 0.5, 0.75]).round(3).tolist()
        res["kwh_per_cdd65"][s] = dict(q25_med_q75=q, n=int(len(d)))
    json.dump(res, open(ROOT / "out" / "recs_evidence.json", "w"), indent=1)
    for k, v in res.items():
        print(k, json.dumps(v))
