"""Figure: observed heat episodes (daily and hourly temperatures)."""
import sys, numpy as np, matplotlib
matplotlib.use("Agg"); import matplotlib.pyplot as plt
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]; sys.path.insert(0, str(ROOT / "data"))
from wx_observed_2023 import ASOS, START
plt.rcParams.update({"font.size": 8, "font.family": "serif", "axes.linewidth": .6,
                     "axes.spines.top": False, "axes.spines.right": False,
                     "axes.grid": True, "grid.color": "#e4e3df", "grid.linewidth": .5})
C1, C2, INK2 = "#2a78d6", "#eb6834", "#52514e"
F2C = lambda f: (f - 32) * 5 / 9
# NOAA LCD daily summary, Houston Hobby, August 2023 (Tmax F, Tmin F)
DMAX = [101,101,99,101,101,101,102,100,101,102,102,102,102,103,104,100,103,102,103,107,100,97,101,107,101,104,109,100,98,101,100]
DMIN = [82,79,81,81,80,81,81,81,81,81,82,83,80,79,83,80,78,79,79,82,82,84,81,82,81,80,80,80,81,78,77]

fig = plt.figure(figsize=(7.2, 5.6))
gs = fig.add_gridspec(2, 3, height_ratios=[1, 1.05], hspace=.55, wspace=.28)
ax = fig.add_subplot(gs[0, :])
d = np.arange(1, 32)
tmax, tmin = F2C(np.array(DMAX)), F2C(np.array(DMIN))
for a, b in [(20, 22), (25, 27)]:
    ax.axvspan(a - .5, b + .5, color="#eeedea", zorder=0, lw=0)
ax.vlines(d, tmin, tmax, color="#b8b7b2", lw=2.2, zorder=1)
ax.plot(d, tmax, "o", ms=3.4, color=C2, zorder=3, label="Daily maximum")
ax.plot(d, tmin, "o", ms=3.4, color=C1, zorder=3, label="Daily minimum")
ax.axhline(F2C(100), color=INK2, lw=.7, ls="--", label="37.8 °C (100 °F)")
ax.text(21, 43.6, "Episode A", ha="center", fontsize=7, color=INK2); ax.text(26, 43.6, "Episode B", ha="center", fontsize=7, color=INK2)
ax.set_xlim(.3, 31.7); ax.set_ylim(23, 45); ax.set_xticks([1, 5, 10, 15, 20, 25, 31])
ax.set_xlabel("Day of August 2023"); ax.set_ylabel("Air temperature (°C)")
ax.set_title("(a) Houston Hobby, August 2023: daily extremes (23 of 31 days reached 37.8 °C)", fontsize=8, loc="left")
ax.legend(frameon=False, fontsize=7, loc="lower left", ncol=3)

panels = [("HOU", 0, "(b) Houston, 20–22 Aug (episode A)"), ("PHX", 0, "(c) Phoenix, 18–20 Jul"), ("MDW", 0, "(d) Chicago, 22–24 Aug")]
for k, (st, off, title) in enumerate(panels):
    recs = [r.split(",") for r in ASOS[st].split(";")]
    T = np.array([float(r[1]) for r in recs]); D = np.array([float(r[2]) for r in recs])
    s = 24 * off; T, D = T[s:s + 96], D[s:s + 96]
    h = np.arange(96) - 24
    a = fig.add_subplot(gs[1, k])
    a.axvspan(-24, 0, color="#f3f2ef", lw=0, zorder=0)
    a.plot(h, T, color=C2, lw=1.6, label="Air temperature")
    a.plot(h, D, color=C1, lw=1.6, label="Dew point")
    a.set_xticks([-24, 0, 24, 48, 72]); a.set_xlim(-24, 71)
    a.set_ylim(0, 50); a.set_title(title, fontsize=8, loc="left")
    a.set_xlabel("Hour (0 = start of analysed episode)")
    if k == 0: a.set_ylabel("Temperature (°C)"); a.text(-12, 2, "spin-up", ha="center", fontsize=6.5, color=INK2)
    a.text(70, T[24:].max() + 1.2, f"peak {T[24:].max():.1f}", ha="right", fontsize=6.5, color=INK2)
h1, l1 = a.get_legend_handles_labels()
fig.legend(h1, l1, frameon=False, ncol=2, fontsize=7, loc="lower center", bbox_to_anchor=(.5, -.005))
fig.subplots_adjust(bottom=.13, top=.95, left=.08, right=.98)
fig.savefig(ROOT / "out" / "fig_episodes.pdf"); fig.savefig(ROOT / "out" / "fig_episodes.png", dpi=170)
print("ok")
