"""Build hourly forcing (96 h = 24 h spin-up + 72 h) from observed records."""
import sys, numpy as np
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "data"))
from wx_observed_2023 import ASOS, GHI, START, EPISODES

def psat(t): return 610.94*np.exp(17.625*t/(t+243.04))

def series(st):
    recs=[r.split(",") for r in ASOS[st].split(";")]
    T=np.array([float(r[1]) for r in recs]); D=np.array([float(r[2]) for r in recs])
    G=np.array([float(x) for x in GHI[st].split(",")])
    return T,D,G

for ep,(st,offday) in EPISODES.items():
    T,D,G=series(st)
    assert len(T)==len(G), (st,len(T),len(G))
    s=24*offday; T,D,G=T[s:s+96],D[s:s+96],G[s:s+96]
    assert len(T)==96, (ep,len(T))
    RH=np.clip(100*psat(D)/psat(T),5,100)
    np.savez(ROOT/"work"/f"forcing_{ep}.npz",T_out=T,RH_out=RH,I_sol=G,dewpt=D)
    v=T[24:]; night=v[[k for k in range(72) if k%24<6]].mean()
    print(f"{ep:6s} T {v.min():5.1f}-{v.max():5.1f} mean {v.mean():5.1f} night {night:5.1f} | Td {D[24:].mean():5.1f} | RH {RH[24:].min():3.0f}-{RH[24:].max():3.0f} | GHI max {G[24:].max():4.0f}")
