"""Results figures for the revised manuscript."""
import json, numpy as np, matplotlib
matplotlib.use("Agg"); import matplotlib.pyplot as plt
from matplotlib.colors import TwoSlopeNorm, LinearSegmentedColormap
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]; OUT = ROOT / "out"
plt.rcParams.update({"font.size": 8, "font.family": "serif", "axes.linewidth": .6,
                     "axes.spines.top": False, "axes.spines.right": False})
INK2 = "#52514e"; GRID = "#e4e3df"
COL = {"M1": "#2a78d6", "M2": "#eda100", "M3": "#e87ba4", "M4": "#1baf7a"}
NAME = {"M1": "Energy share (M1)", "M2": "Exposure averted (M2)", "M3": "Strain averted (M3)", "M4": "Heat burden (M4)"}
CUR = ["M1", "M2", "M3", "M4"]
RUNS = [("HOU-A", "Houston A"), ("HOU-B", "Houston B"), ("PHX", "Phoenix"), ("CHI", "Chicago"),
        ("HOU-A-UQ", "Houston A, param. uncertainty"), ("HOU-A-FAN", "Houston A, fan use"),
        ("PHX-FAN", "Phoenix, fan use")]
A = {r: json.load(open(OUT / f"analysis_{r}.json")) for r, _ in RUNS if (OUT / f"analysis_{r}.json").exists()}
RUNS = [(r, l) for r, l in RUNS if r in A]
BASE = [(r, l) for r, l in RUNS if r in ("HOU-A", "HOU-B", "PHX", "CHI")]
FPL = ["0-100%", "100-150%", "150-200%", "200-300%", "300-400%", "400%+"]
CITY = [("HOU", "Houston", "#2a78d6"), ("PHX", "Phoenix", "#eb6834"), ("CHI", "Chicago", "#1baf7a")]

# ---------------- Figure: stocks and occupants ----------------
fig, ax = plt.subplots(1, 4, figsize=(7.2, 2.3))
for c, lab, col in CITY:
    P = np.load(ROOT / "work" / f"stock_{c}.npz", allow_pickle=True)
    x = np.array([FPL.index(f) for f in P["fpl"]]); ua = P["UA"] / (P["Cap"] / 120e3)
    stat = lambda v, fn: [fn(v[x == i]) if (x == i).sum() >= 10 else np.nan for i in range(6)]
    ax[0].plot(range(6), stat(ua, np.median), "o-", ms=3.5, lw=1.4, color=col, label=lab)
    ax[1].plot(range(6), stat((P["age"] >= 65) * 100.0, np.mean), "o-", ms=3.5, lw=1.4, color=col)
    ct = np.array([m["HVAC Cooling Type"] for m in json.load(open(ROOT / "work" / f"stock_{c}_meta.json"))])
    ax[2].plot(range(6), stat(np.isin(ct, ["None", "Room AC"]) * 100.0, np.mean), "o-", ms=3.5, lw=1.4, color=col)
    ax[3].plot(range(6), stat(P["Tset"], np.median), "o-", ms=3.5, lw=1.4, color=col)
titles = ["(a) Heat loss per floor\narea (W K$^{-1}$, rel.)", "(b) Occupant aged\n65 or over (%)",
          "(c) No cooling or room\nunit only (%)", "(d) Reported cooling\nsetpoint (°C)"]
for a, t in zip(ax, titles):
    a.set_xticks(range(6)); a.set_xticklabels(["<100", "100-\n150", "150-\n200", "200-\n300", "300-\n400", ">400"], fontsize=5.6)
    a.set_title(t, fontsize=7, loc="left"); a.grid(axis="y", color=GRID, lw=.5)
fig.text(.5, .005, "Household income (% of federal poverty line)", ha="center", fontsize=7)
fig.legend(*ax[0].get_legend_handles_labels(), frameon=False, fontsize=6.8, ncol=3, loc="lower center", bbox_to_anchor=(.5, -.07))
plt.tight_layout(rect=(0, .07, 1, 1)); fig.texts[0].set_position((.5, .045)); plt.savefig(OUT / "fig_stocks.pdf", bbox_inches="tight"); plt.savefig(OUT / "fig_stocks.png", dpi=160, bbox_inches="tight"); plt.close()

# ---------------- Figure: agreement between allocations ----------------
pairs = [("M1-M3", "Energy vs strain averted"), ("M2-M3", "Exposure vs strain averted"),
         ("M1-M4", "Energy vs heat burden"), ("M3-M4", "Strain averted vs heat burden")]
pc = ["#2a78d6", "#eda100", "#1baf7a", "#e87ba4"]
fig, ax = plt.subplots(1, 2, figsize=(7.2, 2.9), gridspec_kw={"width_ratios": [1.3, 1]})
y = np.arange(len(RUNS))[::-1].astype(float)
for k, (p, lab) in enumerate(pairs):
    off = (1.5 - k) * .17
    pt = [A[r]["base"]["rho"][p] for r, _ in RUNS]
    lo = [A[r]["boot"][f"rho_{p}"]["lo"] for r, _ in RUNS]; hi = [A[r]["boot"][f"rho_{p}"]["hi"] for r, _ in RUNS]
    ax[0].hlines(y + off, lo, hi, color=pc[k], lw=1.2); ax[0].plot(pt, y + off, "o", ms=3.8, color=pc[k], label=lab)
    mg = [100 * A[r]["base"]["mig"][p] for r, _ in RUNS]
    ax[1].barh(y + off, mg, height=.16, color=pc[k])
ax[0].set_yticks(y); ax[0].set_yticklabels([l for _, l in RUNS], fontsize=6.8); ax[0].set_xlim(0, 1.0)
ax[0].set_xlabel("Rank correlation (1 = identical priority order)", fontsize=7)
ax[0].set_title("(a) Agreement between allocations", fontsize=8, loc="left"); ax[0].grid(axis="x", color=GRID, lw=.5)
fig.legend(*ax[0].get_legend_handles_labels(), frameon=False, fontsize=6.5, loc="lower center", bbox_to_anchor=(.5, 0), ncol=4)
ax[1].set_yticks(y); ax[1].set_yticklabels([]); ax[1].set_xlim(0, 100)
ax[1].set_xlabel("Homes in a different quartile (%)", fontsize=7)
ax[1].set_title("(b) Homes whose priority changes", fontsize=8, loc="left"); ax[1].grid(axis="x", color=GRID, lw=.5)
fig.subplots_adjust(left=.22, right=.98, top=.9, bottom=.25, wspace=.08); plt.savefig(OUT / "fig_reorder.pdf", bbox_inches="tight"); plt.savefig(OUT / "fig_reorder.png", dpi=160, bbox_inches="tight"); plt.close()

# ---------------- Figure: outcomes by group (base episodes) ----------------
GRP = [("lowinc", "Low\nincome"), ("age65", "Aged\n65+"), ("median", "Median\nhome"), ("all", "All\n(mean)")]
fig, axs = plt.subplots(1, len(BASE), figsize=(7.2, 2.6), sharey=False)
axs = np.atleast_1d(axs)
for p, (r, lab) in enumerate(BASE):
    o = A[r]["base"]["out"]; u = A[r]["unmit_groups"]["SR"]
    for gi, (g, gl) in enumerate(GRP):
        for k, c in enumerate(CUR):
            axs[p].bar(gi + (k - 1.5) * .2, o[c]["SR"][g], width=.18, color=COL[c], label=NAME[c] if (p == 0 and gi == 0) else None)
    axs[p].set_xticks(range(len(GRP))); axs[p].set_xticklabels([gl for _, gl in GRP], fontsize=6.2)
    axs[p].set_title(lab, fontsize=7.5, loc="left"); axs[p].grid(axis="y", color=GRID, lw=.5)
    if p == 0: axs[p].set_ylabel("Heat strain (°C·h over 72 h)", fontsize=7)
fig.legend(frameon=False, ncol=4, fontsize=6.5, loc="lower center", bbox_to_anchor=(.5, -.03))
plt.tight_layout(rect=(0, .07, 1, 1)); plt.savefig(OUT / "fig_outcomes.pdf"); plt.savefig(OUT / "fig_outcomes.png", dpi=160); plt.close()

# ---------------- Figure: change vs energy-share across health metrics ----------------
METR = [("SR", "Strain"), ("H38", "Hours core ≥38 °C"), ("SW", "Sweat loss"), ("HI", "Heat-index danger h")]
GR2 = [("lowinc", "Low\nincome"), ("poverty", "Below\npoverty"), ("age65", "Aged\n65+"), ("all", "All\nhomes")]
fig, axs = plt.subplots(2, 1, figsize=(7.2, 5.6), sharex=True)
cm = LinearSegmentedColormap.from_list("d", ["#1c5cab", "#f0efec", "#c45a1c"])
SHORT = ["strain", "h≥38°C", "sweat", "HI h"]
for p, new in enumerate(["M3", "M4"]):
    M = np.full((len(RUNS), len(METR) * len(GR2)), np.nan)
    for gi, (g, _) in enumerate(GR2):
        for mi, (mk, _) in enumerate(METR):
            for ri, (r, _) in enumerate(RUNS):
                o = A[r]["base"]["out"]; a, b = o["M1"][mk].get(g), o[new][mk].get(g)
                if a is not None and b is not None and abs(a) > 1e-3: M[ri, gi * 4 + mi] = 100 * (b - a) / a
    im = axs[p].imshow(M, cmap=cm, norm=TwoSlopeNorm(0, -60, 60), aspect="auto")
    for i in range(M.shape[0]):
        for j in range(M.shape[1]):
            if np.isfinite(M[i, j]):
                axs[p].text(j, i, ("0" if round(M[i, j]) == 0 else (">+300" if M[i, j] > 300 else f"{M[i, j]:+.0f}")), ha="center", va="center", fontsize=6.4,
                            color="white" if abs(M[i, j]) > 42 else "#0b0b0b")
    for bnd in range(1, len(GR2)): axs[p].axvline(bnd * 4 - .5, color="#333333", lw=1.2)
    axs[p].set_yticks(range(len(RUNS))); axs[p].set_yticklabels([l for _, l in RUNS], fontsize=7)
    axs[p].set_title(f"({'ab'[p]}) {NAME[new]} compared with energy share (M1)", fontsize=8, loc="left"); axs[p].tick_params(length=0)
    sec = axs[p].secondary_xaxis("top"); sec.set_xticks(range(16)); sec.set_xticklabels(SHORT * 4, fontsize=5.5, rotation=90); sec.tick_params(length=0)
axs[1].set_xticks(np.arange(len(GR2)) * 4 + 1.5); axs[1].set_xticklabels([l.replace("\n", " ") for _, l in GR2], fontsize=7.5)
fig.subplots_adjust(hspace=0.42)
cb = fig.colorbar(im, ax=axs, shrink=.7, pad=.015); cb.set_label("Change relative to M1 (%); negative = better protected", fontsize=7); cb.ax.tick_params(labelsize=6.5)
fig.text(.02, .02, "strain: heat strain; h≥38°C: hours with core temperature ≥38 °C; sweat: sweat loss; HI h: hours with indoor heat index ≥39.4 °C.\nBlank: outcome is zero under M1. Colours are capped at ±60 %; changes above +300 % are shown as >+300.", fontsize=6.3, color=INK2)
plt.savefig(OUT / "fig_health.pdf", bbox_inches="tight"); plt.savefig(OUT / "fig_health.png", dpi=160, bbox_inches="tight"); plt.close()

# ---------------- Figure: sweep (low-income strain, M4 vs best proportional currency) ----------------
fig, axs = plt.subplots(1, len(BASE), figsize=(7.2, 2.1), sharey=True); axs = np.atleast_1d(axs)
etas = [0.5, 1.0, 2.0, 4.0]; bs = [0.30, 0.45, 0.60]
cm2 = LinearSegmentedColormap.from_list("d", ["#c45a1c", "#f0efec", "#1c5cab"])
for p, (r, l) in enumerate(BASE):
    M = np.zeros((4, 3))
    for row in A[r]["sweep"]:
        i, j = etas.index(row["eta"]), bs.index(row["b"])
        best = min(row[c]["lowinc"] for c in ["M1", "M2", "M3"])
        M[i, j] = 100 * (best - row["M4"]["lowinc"]) / best if best else 0
    im = axs[p].imshow(M, cmap=cm2, norm=TwoSlopeNorm(0, -60, 60), aspect="auto")
    for i in range(4):
        for j in range(3): axs[p].text(j, i, f"{M[i, j]:+.0f}", ha="center", va="center", fontsize=6.3)
    axs[p].set_xticks(range(3)); axs[p].set_xticklabels([f"{int(100*b)}%" for b in bs], fontsize=6.5)
    axs[p].set_yticks(range(4)); axs[p].set_yticklabels(etas, fontsize=6.5)
    axs[p].set_title(l, fontsize=7.5, loc="left"); axs[p].set_xlabel("Energy budget", fontsize=7); axs[p].tick_params(length=0)
    for s in axs[p].spines.values(): s.set_visible(False)
axs[0].set_ylabel("Inequality aversion η", fontsize=7)
cb = fig.colorbar(im, ax=axs, shrink=.85, pad=.01); cb.set_label("Low-income strain reduction, M4\nvs best of M1–M3 (%)", fontsize=6.2); cb.ax.tick_params(labelsize=6)
plt.savefig(OUT / "fig_sweep.pdf", bbox_inches="tight"); plt.savefig(OUT / "fig_sweep.png", dpi=160, bbox_inches="tight"); plt.close()
print("figures written for", [r for r, _ in RUNS])
