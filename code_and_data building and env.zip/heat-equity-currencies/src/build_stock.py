"""
Stage 1. Sample three metropolitan housing stocks, map them to 1R1C thermal
parameters, and attach occupants drawn from RECS 2020 microdata.

Stocks (national residential stock model, conditioned on climate zone and county):
  HOU  Harris County, TX      IECC 2A  hot-humid
  PHX  Maricopa County, AZ    IECC 2B  hot-dry
  CHI  Cook County, IL        IECC 5A  cold, humid summers

Occupants are drawn jointly with the dwelling. For each sampled
dwelling a donor household is drawn from RECS 2020 respondents in the same
state, matching building type, tenure and poverty band (with documented
fall-back), with probability proportional to the survey weight. The donor
supplies householder age and sex, household size and the reported summer
cooling setpoint.

    python src/build_stock.py --n 300
"""
import argparse, csv, json, re, sys
import numpy as np
import pandas as pd
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from resstock_sampler import sample, HC

CITIES = {
    "HOU": dict(cz="2A", county="G4802010", state="TX", label="Houston (Harris County, TX)"),
    "PHX": dict(cz="2B", county="G0400130", state="AZ", label="Phoenix (Maricopa County, AZ)"),
    "CHI": dict(cz="5A", county="G1700310", state="IL", label="Chicago (Cook County, IL)"),
}
FPL_BINS = ["0-100%", "100-150%", "150-200%", "200-300%", "300-400%", "400%+"]
TARGETS = ["Vintage", "Geometry Building Type RECS", "Geometry Floor Area",
           "Insulation Wall", "Insulation Ceiling", "Windows", "Window Areas",
           "Infiltration", "HVAC Cooling Type", "Federal Poverty Level",
           "Occupants", "Tenure", "Geometry Stories", "Geometry Wall Type",
           "Vacancy Status"]

# ------------------------------------------------------------------ parsers
def rval(s):
    m = re.search(r"R-(\d+)", s)
    return float(m.group(1)) if m else 0.0

def ach50(s):
    m = re.search(r"(\d+)\s*ACH50", s)
    return float(m.group(1)) if m else 15.0

def sqft(s):
    n = [float(x) for x in re.findall(r"\d+", s.replace("+", ""))]
    if not n: return 1500.0
    return n[0] * (1.25 if "+" in s else 1.0) if len(n) == 1 else float(np.mean(n))

def stories(s):
    m = re.match(r"(\d+)", s)
    return float(m.group(1)) if m else 1.0

def winq(s):
    if s == "Void": return 0.0
    return ({"Single": 0., "Double": 1., "Triple": 2.}[s.split(",")[0].strip()]
            + ("Low-E" in s) + ("Non-metal" in s) + 0.5 * ("Storm" in s))

def wwr(s):
    n = [float(x) for x in re.findall(r"\d+", s)]
    return (np.mean(n) / 100.0) if n else 0.15

R_IP2SI = 0.1761
CAP_PER_M2 = {"Brick": 250e3, "Concrete": 300e3, "Steel Frame": 150e3, "Wood Frame": 120e3}

# ------------------------------------------------------------------ RECS
def load_recs():
    use = ["DOEID", "state_postal", "TYPEHUQ", "KOWNRENT", "MONEYPY", "NHSLDMEM",
           "HHAGE", "HHSEX", "TEMPHOMEAC", "AIRCOND", "NWEIGHT", "HOTMA",
           "KWHCOL", "CDD65", "NUMADULT2"]
    df = pd.read_csv(ROOT / "data" / "recs2020_public_v7.csv", usecols=use, low_memory=False)
    # income bin midpoints (USD, 2020), code 1..16
    mid = {1: 2500, 2: 6250, 3: 8750, 4: 11250, 5: 13750, 6: 17500, 7: 22500,
           8: 27500, 9: 32500, 10: 37500, 11: 45000, 12: 55000, 13: 67500,
           14: 87500, 15: 125000, 16: 200000}
    guide = 12760 + 4480 * (df.NHSLDMEM.clip(lower=1) - 1)       # HHS 2020, contiguous US
    pct = 100 * df.MONEYPY.map(mid) / guide
    df["FPL"] = pd.cut(pct, [-1, 100, 150, 200, 300, 400, 1e9], labels=FPL_BINS).astype(str)
    df["BT"] = df.TYPEHUQ.map({1: "Mobile Home", 2: "Single-Family Detached",
                               3: "Single-Family Attached",
                               4: "Multi-Family with 2 - 4 Units",
                               5: "Multi-Family with 5+ Units"})
    df["TEN"] = df.KOWNRENT.map({1: "Owner", 2: "Renter", 3: "Renter"})
    return df

def draw_donor(df, state, bt, ten, fpl, rng):
    """Weighted donor draw with progressive relaxation; returns row and match level."""
    s = df[df.state_postal == state]
    tiers = [((s.BT == bt) & (s.TEN == ten) & (s.FPL == fpl), 0),
             ((s.TEN == ten) & (s.FPL == fpl), 1),
             ((s.FPL == fpl), 2),
             ((s.TEN == ten), 3)]
    for mask, lvl in tiers:
        c = s[mask]
        if len(c) >= 5:
            p = c.NWEIGHT.values / c.NWEIGHT.sum()
            return c.iloc[rng.choice(len(c), p=p)], lvl
    p = s.NWEIGHT.values / s.NWEIGHT.sum()
    return s.iloc[rng.choice(len(s), p=p)], 4

# ------------------------------------------------------------------ main
def county_weights(cz, prefix):
    r = list(csv.reader(open(Path(HC) / "County and PUMA.tsv"), delimiter="\t"))
    hdr = r[0]; oi = [i for i, h in enumerate(hdr) if h.startswith("Option=")]
    row = [x for x in r[1:] if x and x[0] == cz][0]
    return {hdr[i][7:]: float(row[i]) for i in oi
            if hdr[i][7:].startswith(prefix) and float(row[i]) > 0}

def build(city, n, seed, recs):
    cfg = CITIES[city]; rng = np.random.default_rng(seed)
    w = county_weights(cfg["cz"], cfg["county"])
    pool, _ = sample(int(n * 1.35), TARGETS,
                     fixed={"ASHRAE IECC Climate Zone 2004": cfg["cz"], "County and PUMA": w},
                     seed=seed)
    occ = [r for r in pool if r["Vacancy Status"] == "Occupied"
           and r["Federal Poverty Level"] in FPL_BINS][:n]          # exact conditioning by rejection
    assert len(occ) == n, f"{city}: only {len(occ)} occupied draws"

    P = {k: np.zeros(n) for k in ["UA", "Cap", "Asol", "Qint", "Qmax", "Tset",
                                   "height", "weight", "fat"]}
    age = np.zeros(n, int); sex = []; fpl = []; match = np.zeros(n, int)
    hhsize = np.zeros(n, int); meta = []
    for i, r in enumerate(occ):
        A_f = sqft(r["Geometry Floor Area"]) * 0.0929
        mf = r["Geometry Building Type RECS"].startswith("Multi-Family")
        # for multifamily units "Geometry Stories" is the building height; the
        # unit itself is one storey with about half of its perimeter exposed
        st = 1.0 if mf else stories(r["Geometry Stories"]); foot = A_f / st
        A_wall = 4 * np.sqrt(max(foot, 20.0)) * 2.7 * st * (0.5 if mf else 1.0)
        A_win = wwr(r["Window Areas"]) * A_wall
        U_wall = 1.0 / max((rval(r["Insulation Wall"]) + 5.0) * R_IP2SI, 0.10)
        U_ceil = 1.0 / max((rval(r["Insulation Ceiling"]) + 4.0) * R_IP2SI, 0.10)
        wq = winq(r["Windows"]); U_win = max(5.9 - 1.4 * wq, 1.4); SHGC = max(0.70 - 0.12 * wq, 0.25)
        if mf:
            A_ceil = foot * 0.35          # share of units under a roof
        else:
            A_ceil = foot
        UA_inf = ach50(r["Infiltration"]) / 17.0 * A_f * 2.7 * 1200.0 / 3600.0
        P["UA"][i] = U_wall * (A_wall - A_win) + U_ceil * A_ceil + U_win * A_win + UA_inf
        P["Cap"][i] = A_f * CAP_PER_M2.get(r["Geometry Wall Type"], 120e3)
        P["Asol"][i] = A_win * SHGC * 0.5

        donor, lvl = draw_donor(recs, cfg["state"], r["Geometry Building Type RECS"],
                                r["Tenure"], r["Federal Poverty Level"], rng)
        match[i] = lvl
        nocc = int(max(1, donor.NHSLDMEM)); hhsize[i] = nocc
        P["Qint"][i] = 80.0 + 60.0 * nocc
        age[i] = int(np.clip(donor.HHAGE, 18, 90))
        s_ = "female" if donor.HHSEX == 1 else "male"; sex.append(s_)
        tset_f = donor.TEMPHOMEAC if donor.TEMPHOMEAC > 0 else 78.0
        P["Tset"][i] = float(np.clip((tset_f - 32) * 5 / 9, 20.0, 29.0))

        design = P["UA"][i] * 13.0 + P["Asol"][i] * 880 * 0.35 * 0.6 + P["Qint"][i]
        ct = r["HVAC Cooling Type"]
        if ct in ("Central AC", "Ducted Heat Pump", "Non-Ducted Heat Pump"):
            P["Qmax"][i] = min(design * 1.05, 21000.0)
        elif ct in ("Room AC",):
            P["Qmax"][i] = min(design * 1.05, 3500.0)
        elif ct == "Evaporative or Swamp Cooler":
            P["Qmax"][i] = min(design * 1.05, 6000.0)
        else:
            P["Qmax"][i] = 0.0
        fpl.append(r["Federal Poverty Level"])
        meta.append({k: r[k] for k in TARGETS} | {"recs_doeid": int(donor.DOEID), "match": int(lvl)})

    sex = np.array(sex)
    P["height"] = np.where(sex == "male", 1.75, 1.62) + rng.normal(0, 0.06, n)
    P["weight"] = np.where(sex == "male", 86, 74) + rng.normal(0, 12, n)
    P["fat"] = np.clip(np.where(sex == "male", 24, 34) + rng.normal(0, 4, n), 10, 45)
    rank = {f: k for k, f in enumerate(FPL_BINS)}
    dep = np.array([1.0 - rank[f] / 5.0 for f in fpl])
    np.savez(ROOT / "work" / f"stock_{city}.npz", age=age, sex=sex, fpl=np.array(fpl),
             dep=dep, match=match, hhsize=hhsize, **P)
    json.dump(meta, open(ROOT / "work" / f"stock_{city}_meta.json", "w"))
    return P, age, dep, match

def spear(a, b):
    ra, rb = (np.argsort(np.argsort(x)).astype(float) for x in (a, b))
    ra -= ra.mean(); rb -= rb.mean()
    return float(ra @ rb / np.sqrt((ra @ ra) * (rb @ rb)))

if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("--n", type=int, default=300)
    a = ap.parse_args()
    recs = load_recs()
    for k, city in enumerate(CITIES):
        P, age, dep, match = build(city, a.n, 101 + k, recs)
        print(f"{city}: UA med {np.median(P['UA']):.0f} W/K | no cooling {(P['Qmax']==0).sum()} | "
              f"65+ {(age>=65).mean():.0%} | Tset med {np.median(P['Tset']):.1f} C | "
              f"rho(dep,age) {spear(dep,age):+.2f} | rho(dep,UA/A) {spear(dep,P['UA']/(P['Cap']/120e3)):+.2f} | "
              f"exact match {(match==0).mean():.0%}")
