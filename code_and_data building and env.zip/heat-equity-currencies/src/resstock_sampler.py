"""
Generic ResStock housing-characteristic sampler.

Reads the project_national/housing_characteristics/*.tsv conditional
probability tables, resolves the dependency DAG topologically, and draws
joint samples. Optionally conditions the draw on fixed attribute values
(e.g. a specific set of PUMAs) to restrict the sample to one metro.
"""
import csv, os, numpy as np
from pathlib import Path
from collections import defaultdict

HC = os.environ.get("RESSTOCK_HC", str(Path(__file__).resolve().parents[1] / "data" / "resstock" / "project_national" / "housing_characteristics"))


class Table:
    def __init__(self, path):
        self.name = os.path.basename(path)[:-4]
        rows = list(csv.reader(open(path), delimiter="\t"))
        hdr = rows[0]
        self.deps = [h[len("Dependency="):] for h in hdr if h.startswith("Dependency=")]
        self.opts = [h[len("Option="):] for h in hdr if h.startswith("Option=")]
        di = [i for i, h in enumerate(hdr) if h.startswith("Dependency=")]
        oi = [i for i, h in enumerate(hdr) if h.startswith("Option=")]
        self.lut = {}
        for r in rows[1:]:
            if not r or r[0].startswith("#"):
                continue
            key = tuple(r[i] for i in di)
            try:
                p = np.array([float(r[i]) for i in oi])
            except (ValueError, IndexError):
                continue
            self.lut[key] = p

    def draw(self, state, rng):
        key = tuple(str(state[d]) for d in self.deps)
        p = self.lut.get(key)
        if p is None:                       # unseen combination
            return None
        s = p.sum()
        if s <= 0:
            return None
        return self.opts[rng.choice(len(p), p=p / s)]


def load(names):
    """Load the named tables plus every table they transitively depend on."""
    tables, queue, seen = {}, list(names), set()
    while queue:
        n = queue.pop()
        if n in seen:
            continue
        seen.add(n)
        path = os.path.join(HC, n + ".tsv")
        if not os.path.exists(path):
            tables[n] = None                # leaf we cannot resolve
            continue
        t = Table(path)
        tables[n] = t
        queue.extend(t.deps)
    return tables


def toposort(tables):
    order, temp, perm = [], set(), set()

    def visit(n):
        if n in perm or n in temp:
            return
        temp.add(n)
        t = tables.get(n)
        if t is not None:
            for d in t.deps:
                visit(d)
        temp.discard(n)
        perm.add(n)
        order.append(n)

    for n in list(tables):
        visit(n)
    return order


def sample(n_samples, targets, fixed=None, seed=0, max_tries=60):
    """Draw n_samples joint records. `fixed` maps attribute -> value or list."""
    fixed = fixed or {}
    tables = load(targets)
    order = toposort(tables)
    rng = np.random.default_rng(seed)
    out, fails = [], defaultdict(int)
    while len(out) < n_samples:
        ok = True
        for _try in range(max_tries):
            st = {}
            for k, v in fixed.items():
                if isinstance(v, dict):          # {option: probability}
                    ks = list(v); ps = np.array([v[x] for x in ks], dtype=float)
                    st[k] = ks[rng.choice(len(ks), p=ps / ps.sum())]
                elif isinstance(v, (list, tuple)):
                    st[k] = rng.choice(v)
                else:
                    st[k] = v
            ok = True
            for name in order:
                if name in st:
                    continue
                t = tables.get(name)
                if t is None:
                    st[name] = "Not Available"
                    continue
                val = t.draw(st, rng)
                if val is None:
                    fails[name] += 1
                    ok = False
                    break
                st[name] = val
            if ok:
                break
        if not ok:
            raise RuntimeError(f"sampling failed; top blockers: "
                               f"{sorted(fails.items(), key=lambda x: -x[1])[:5]}")
        out.append(st)
    return out, dict(sorted(fails.items(), key=lambda x: -x[1])[:8])
