"""
Stage 4. Exact allocation under four equity currencies, outcome evaluation on
several health metrics, threshold sensitivity, robustness sweep and bootstrap.

Currencies (service level x_i in [0, 1] for each dwelling):
  M1  energy     share of the dwelling's unrestricted cooling energy received
  M2  exposure   fraction of the dwelling's indoor degree-hours (>26 C) averted
  M3  strain     fraction of the occupant's own heat strain averted
  M4  burden     1 - residual heat strain / largest unmitigated strain in stock
                 (absolute physiological burden, not normalised per person)

    python src/analyse.py --runs HOU-A PHX CHI HOU-A-UQ HOU-A-FAN PHX-FAN HOU-B
"""
import argparse, itertools, json
import numpy as np
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
GRID = 0.5
EPS = 1e-9
CURRENCIES = ["M1", "M2", "M3", "M4"]
HEALTH = {"SR": "heat strain: core rise above own usual level (C h)",
          "H38": "hours with core >= 38 C", "PK": "peak core temperature (C)",
          "SW": "sweat loss (% body mass per day)", "HI": "hours indoor heat index >= 39.4 C"}
GROUPS = ["lowinc", "poverty", "age65", "all"]

def service(D, cur, sk="SR"):
    if cur == "M1":
        base = D["E"][:, -1:]; g = D["E"] / np.maximum(base, EPS); g[base[:, 0] < EPS] = 1.0
        return g
    if cur == "M4":
        X = D[sk]; return 1.0 - X / max(float(X[:, 0].max()), EPS)
    X = D["DH"] if cur == "M2" else D[sk]
    base = X[:, :1]; g = np.clip((base - X) / np.maximum(base, EPS), 0, 1); g[base[:, 0] < EPS] = 1.0
    return g

def welfare(x, eta):
    x = np.clip(x, 1e-4, 1.0)
    return np.log(x) if abs(eta - 1) < 1e-9 else x ** (1 - eta) / (1 - eta)

def solve(D, idx, cur, eta, budget, sk="SR"):
    """Exact multiple-choice knapsack by dynamic programming over the budget."""
    v = welfare(service(D, cur, sk)[idx], eta)
    c = np.rint(D["E"][idx] / GRID).astype(int)
    B = int(round(budget / GRID)); n, L = c.shape
    dp = np.full(B + 1, -1e18); dp[0] = 0.0
    ch = np.zeros((n, B + 1), np.int8)
    for i in range(n):
        best = np.full(B + 1, -1e18); bj = np.zeros(B + 1, np.int8)
        for j in range(L):
            cj = c[i, j]
            if cj > B: continue
            cand = np.full(B + 1, -1e18); cand[cj:] = dp[:B + 1 - cj] + v[i, j]
            u = cand > best; best[u] = cand[u]; bj[u] = j
        dp, ch[i] = best, bj
    b = int(np.argmax(dp)); lev = np.zeros(n, int)
    for i in range(n - 1, -1, -1):
        lev[i] = ch[i, b]; b -= c[i, lev[i]]
    return lev

def spearman(a, b):
    ra, rb = (np.argsort(np.argsort(x, kind="stable")).astype(float) for x in (a, b))
    ra -= ra.mean(); rb -= rb.mean(); den = np.sqrt((ra @ ra) * (rb @ rb))
    return float(ra @ rb / den) if den > 0 else 1.0

def migration(a, b):
    qa = np.digitize(a, np.quantile(a, [.25, .5, .75])); qb = np.digitize(b, np.quantile(b, [.25, .5, .75]))
    return float((qa != qb).mean())

def groups_for(D, idx):
    d = D["d"][idx]; age = D["age"][idx]
    return {"poverty": d >= 0.999, "lowinc": d >= 0.799, "age65": age >= 65, "all": np.ones(len(idx), bool)}

def outcomes(D, idx, lev, g):
    r = {}
    for h in HEALTH:
        y = D[h][idx, lev]
        r[h] = {k: float(y[m].mean()) if m.any() else None for k, m in g.items()}
        r[h]["median"] = float(np.median(y)); r[h]["worst"] = float(y.max()); r[h]["total"] = float(y.sum())
    r["E"] = float(D["E"][idx, lev].sum())
    return r

def base_case(D, idx, eta=2.0, bf=0.45, sk="SR"):
    FULL = D["E"][idx, -1].sum(); g = groups_for(D, idx)
    al = {c: solve(D, idx, c, eta, bf * FULL, sk) for c in CURRENCIES}
    rho = {f"{a}-{b}": spearman(al[a], al[b]) for a, b in itertools.combinations(CURRENCIES, 2)}
    mig = {f"{a}-{b}": migration(al[a], al[b]) for a, b in itertools.combinations(CURRENCIES, 2)}
    return {"alloc": {c: al[c].tolist() for c in CURRENCIES},
            "out": {c: outcomes(D, idx, al[c], g) for c in CURRENCIES},
            "rho": rho, "mig": mig, "full_kwh": float(FULL), "n": int(len(idx)),
            "group_n": {k: int(v.sum()) for k, v in g.items()}}

def energy_penalty(D, idx, cur, target, group="lowinc", eta=2.0, bf=0.45):
    """Extra budget (fraction) currency `cur` needs to match `target` mean strain in `group`."""
    FULL = D["E"][idx, -1].sum(); g = groups_for(D, idx)[group]
    val = lambda f: D["SR"][idx, solve(D, idx, cur, eta, f * FULL)][g].mean()
    if val(bf) <= target + 1e-9: return 0.0
    if val(1.0) > target + 1e-9: return None
    lo, hi = bf, 1.0
    for _ in range(12):
        mid = (lo + hi) / 2
        lo, hi = (lo, mid) if val(mid) <= target else (mid, hi)
    return hi / bf - 1.0

def load(run):
    D = dict(np.load(ROOT / "work" / f"curves_{run}.npz"))
    city = run.split("-")[0]
    base = np.load(ROOT / "work" / f"core_base_{city}.npy")[:len(D["E"])]
    core = D["core"].astype(float)
    D["SR"] = np.clip(core - base[:, None, None], 0, None).sum(2)
    D["SR05"] = np.clip(core - base[:, None, None] - 0.5, 0, None).sum(2)
    return D

def analyse(run, nboot):
    D = load(run); n = len(D["E"]); idx = np.arange(n)
    res = {"run": run, "base": base_case(D, idx)}
    o = res["base"]["out"]
    res["penalty"] = {c: energy_penalty(D, idx, c, o["M4"]["SR"]["lowinc"]) for c in ["M1", "M2", "M3"]}
    # threshold sensitivity: strain measured above usual level + 0.5 C, or above 38 C
    res["threshold"] = {}
    g = groups_for(D, idx)
    for sk in ["SR05", "S38"]:
        bc = base_case(D, idx, sk=sk); Y = D[sk]
        al = {c: np.array(bc["alloc"][c]) for c in CURRENCIES}
        res["threshold"][sk] = {"rho": bc["rho"], "mig": bc["mig"],
                                **{k: {c: float(Y[idx, al[c]][g[k]].mean()) for c in CURRENCIES} for k in GROUPS},
                                "total": {c: float(Y[idx, al[c]].sum()) for c in CURRENCIES}}
    # sweep over inequality aversion and budget
    FULL = D["E"][:, -1].sum(); sw = []
    for eta, bf in itertools.product([0.5, 1.0, 2.0, 4.0], [0.30, 0.45, 0.60]):
        row = {"eta": eta, "b": bf}
        for c in CURRENCIES:
            lev = solve(D, idx, c, eta, bf * FULL)
            y = D["SR"][idx, lev]
            row[c] = {"lowinc": float(y[g["lowinc"]].mean()), "age65": float(y[g["age65"]].mean()),
                      "all": float(y.mean()), "median": float(np.median(y))}
        sw.append(row)
    res["sweep"] = sw
    # bootstrap over dwellings
    rng = np.random.default_rng(11); bs = {}
    def add(k, v): bs.setdefault(k, []).append(v)
    for _ in range(nboot):
        ix = rng.integers(0, n, n); bc = base_case(D, ix); oo = bc["out"]
        for k, v in bc["rho"].items(): add(f"rho_{k}", v)
        for k, v in bc["mig"].items(): add(f"mig_{k}", v)
        for new in ["M3", "M4"]:
            for ref in ["M1", "M2"]:
                for gr in GROUPS + ["median"]:
                    a, b = oo[ref]["SR"][gr], oo[new]["SR"][gr]
                    if a: add(f"gain_{new}_{ref}_{gr}", (a - b) / a)
    res["boot"] = {k: {"mean": float(np.mean(v)), "lo": float(np.percentile(v, 2.5)),
                       "hi": float(np.percentile(v, 97.5)), "p_pos": float(np.mean(np.array(v) > 0))}
                   for k, v in bs.items()}
    res["unmitigated"] = {h: {"median": float(np.median(D[h][:, 0])), "max": float(D[h][:, 0].max()),
                              "mean": float(D[h][:, 0].mean())} for h in HEALTH}
    res["fullcool"] = {h: {"median": float(np.median(D[h][:, -1])), "max": float(D[h][:, -1].max()),
                           "mean": float(D[h][:, -1].mean())} for h in HEALTH}
    res["unmit_groups"] = {h: {k: float(D[h][g[k], 0].mean()) for k in GROUPS} for h in HEALTH}
    res["guard"] = int(D["FIX"].sum())
    dS = np.diff(D["SR"], axis=1); viol = np.where(dS > 0, dS, 0).sum(1)
    res["monotone"] = int(sum(np.all(dS[i] <= 1e-6) for i in range(n)))
    res["monotone_1pct"] = int((viol <= 0.01 * np.maximum(D["SR"][:, 0], 1e-9)).sum())
    res["unreachable"] = int((D["E"][:, -1] < EPS).sum())
    json.dump(res, open(ROOT / "out" / f"analysis_{run}.json", "w"), indent=1)
    b = res["base"]; bo = res["boot"]
    print(f"{run}: rho M1-M3 {b['rho']['M1-M3']:.2f} M1-M4 {b['rho']['M1-M4']:.2f} M3-M4 {b['rho']['M3-M4']:.2f} | "
          + " | ".join(f"{c} li {o[c]['SR']['lowinc']:.1f} 65+ {o[c]['SR']['age65']:.1f} med {o[c]['SR']['median']:.1f} all {o[c]['SR']['all']:.1f}"
                       for c in CURRENCIES)
          + f" | M4 vs M1 lowinc {bo['gain_M4_M1_lowinc']['mean']:+.0%} [{bo['gain_M4_M1_lowinc']['lo']:+.0%},{bo['gain_M4_M1_lowinc']['hi']:+.0%}]",
          flush=True)

if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("--runs", nargs="+", required=True)
    ap.add_argument("--boot", type=int, default=100)
    a = ap.parse_args()
    for r in a.runs:
        if (ROOT / "work" / f"curves_{r}.npz").exists(): analyse(r, a.boot)
        else: print("missing", r)
