"""
Stage 3. Coupled dwelling (1R1C) and occupant (JOS-3) simulation producing
response curves for every dwelling and allocation level.

Variants
  base  stock parameters as sampled
  uq    per-dwelling log-normal perturbation of UA, C, A_sol (sigma 0.30) and
        installed capacity (sigma 0.15): envelope-parameter uncertainty
  fan   occupant uses an electric fan (air speed 0.8 m/s) whenever indoor
        temperature exceeds 26 C: behavioural adaptation

    python src/simulate.py --run HOU-A --city HOU --variant base
"""
import argparse, time, warnings
import numpy as np
from multiprocessing import Pool
from pathlib import Path

warnings.filterwarnings("ignore")
ROOT = Path(__file__).resolve().parents[1]
LEVELS = np.linspace(0.0, 1.0, 9)
SPIN, HOURS, SUB = 24, 96, 1200.0
PER_H = int(3600 / SUB)
CLO, PAR = 0.35, 1.1

def psat(t): return 610.94 * np.exp(17.625 * t / (t + 243.04))

def heat_index_c(t, rh):
    """NWS heat index (Rothfusz regression with standard adjustments)."""
    f = t * 9 / 5 + 32
    hi = 0.5 * (f + 61.0 + (f - 68.0) * 1.2 + rh * 0.094)
    full = (-42.379 + 2.04901523 * f + 10.14333127 * rh - 0.22475541 * f * rh
            - 6.83783e-3 * f * f - 5.481717e-2 * rh * rh + 1.22874e-3 * f * f * rh
            + 8.5282e-4 * f * rh * rh - 1.99e-6 * f * f * rh * rh)
    use = (hi + f) / 2 >= 80
    hi = np.where(use, full, hi)
    adj1 = np.where((rh < 13) & (f >= 80) & (f <= 112),
                    -((13 - rh) / 4) * np.sqrt(np.clip((17 - np.abs(f - 95)) / 17, 0, None)), 0)
    adj2 = np.where((rh > 85) & (f >= 80) & (f <= 87), ((rh - 85) / 10) * ((87 - f) / 5), 0)
    hi = hi + np.where(use, adj1 + adj2, 0)
    return (hi - 32) * 5 / 9

G = {}
def init(run, city, variant):
    from pythermalcomfort.models import JOS3
    import jos3 as upstream
    F = np.load(ROOT / "work" / f"forcing_{run.replace('-UQ','').replace('-FAN','')}.npz")
    P = dict(np.load(ROOT / "work" / f"stock_{city}.npz", allow_pickle=True))
    if variant == "uq":
        r = np.random.default_rng(777)
        n = len(P["UA"])
        for k, s in [("UA", .30), ("Cap", .30), ("Asol", .30)]:
            P[k] = P[k] * np.exp(r.normal(-s * s / 2, s, n))
        P["Qmax"] = P["Qmax"] * np.exp(r.normal(-.15 * .15 / 2, .15, n))
    ref = JOS3()
    G.update(F=F, P=P, variant=variant, JOS3=JOS3, up=upstream.JOS3,
             TB=np.array(ref.t_body, float).copy())

def dwelling(i, frac, T_out, I_sol, P):
    """
    1R1C dwelling integrated with the exact solution of the linear ODE over each
    hour (unconditionally stable). The cooling power for the hour is the value
    that brings the indoor temperature exactly to the setpoint at the end of
    the hour, clipped to [0, available capacity] (ideal thermostat, anti-windup).
    """
    UA, C = P["UA"][i], P["Cap"][i]; Tset = P["Tset"][i]; qmax = P["Qmax"][i] * frac
    a = np.exp(-UA * 3600.0 / C)
    T = T_out[0] + 1.0; Tin = np.zeros(HOURS); on = np.zeros(HOURS, bool); q = 0.0
    for k in range(HOURS):
        G = P["Asol"][i] * I_sol[k] * 0.35 + P["Qint"][i]
        T_free = T_out[k] + G / UA + (T - T_out[k] - G / UA) * a       # end-of-hour, no cooling
        q_need = (T_free - Tset) * UA / (1.0 - a)                          # cooling that lands on Tset
        qc = min(max(q_need, 0.0), qmax)
        T = T_free - qc * (1.0 - a) / UA
        if k >= SPIN: q += qc / 1000.0
        Tin[k] = T; on[k] = qc > 0
    return Tin, q, on

def occupant(i, Tin, rh_in, P):
    kw = dict(height=float(P["height"][i]), weight=float(P["weight"][i]),
              fat=float(P["fat"][i]), age=int(P["age"][i]), sex=str(P["sex"][i]))
    m = G["JOS3"](**kw)
    sp = float(np.mean(m.cr_set_point)); fixed = False
    if (not np.isfinite(sp)) or sp < 35.5:
        u = G["up"](height=kw["height"], weight=kw["weight"], fat=kw["fat"],
                    age=kw["age"], sex=kw["sex"])
        m.cr_set_point = np.array(u.setpt_cr, float).copy()
        m.sk_set_point = np.array(u.setpt_sk, float).copy()
        m.t_body = G["TB"].copy(); fixed = True
    m.clo, m.par = CLO, PAR
    core = np.zeros(HOURS); wl = np.zeros(HOURS)
    for k in range(HOURS):
        m.to = float(Tin[k]); m.rh = float(rh_in[k])
        m.v = 0.8 if (G["variant"] == "fan" and Tin[k] > 26.0) else 0.15
        m.simulate(times=PER_H, dtime=SUB, output=True)
        d = m.dict_results()
        core[k] = float(m.t_core[2])
        wl[k] = float(np.asarray(d["weight_loss_by_evap_and_res"][-PER_H:], float).mean()) * 3600.0
        m._history = []                    # keep memory flat
    return core, wl, fixed

def job(i):
    F, P = G["F"], G["P"]
    T_out, RH_out, I_sol = F["T_out"], F["RH_out"], F["I_sol"]
    out = {k: np.zeros(len(LEVELS)) for k in
           ["E", "DH", "S37", "S375", "S38", "H38", "PK", "SW", "HI", "TMAX"]}
    traj = np.zeros((len(LEVELS), HOURS - SPIN), np.float32); fixed = False
    for j, f in enumerate(LEVELS):
        Tin, kwh, on = dwelling(i, f, T_out, I_sol, P)
        # indoor vapour pressure follows outdoor air, except that a running air
        # conditioner dehumidifies: indoor RH is then capped at 60 %
        vp = RH_out / 100.0 * psat(T_out)
        vp = np.where(on, np.minimum(vp, 0.60 * psat(Tin)), vp)
        rh_in = np.clip(100.0 * vp / psat(Tin), 5, 98)
        core, wl, fixed = occupant(i, Tin, rh_in, P)
        c, t, h = core[SPIN:], Tin[SPIN:], heat_index_c(Tin[SPIN:], rh_in[SPIN:])
        out["E"][j] = kwh
        out["DH"][j] = np.clip(t - 26.0, 0, None).sum()
        out["S37"][j] = np.clip(c - 37.0, 0, None).sum()
        out["S375"][j] = np.clip(c - 37.5, 0, None).sum()
        out["S38"][j] = np.clip(c - 38.0, 0, None).sum()
        out["H38"][j] = float((c >= 38.0).sum())
        out["PK"][j] = c.max()
        out["SW"][j] = 100.0 * wl[SPIN:].sum() / 1000.0 / P["weight"][i] / 3.0   # % body mass per day
        out["HI"][j] = float((h >= 39.4).sum())                                    # NWS 'danger' hours
        out["TMAX"][j] = t.max()
        traj[j] = c
    return i, out, traj, fixed

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--run", required=True); ap.add_argument("--city", required=True)
    ap.add_argument("--variant", default="base", choices=["base", "uq", "fan"])
    ap.add_argument("--workers", type=int, default=2)
    ap.add_argument("--limit", type=int, default=0)
    a = ap.parse_args()
    n = len(np.load(ROOT / "work" / f"stock_{a.city}.npz")["UA"])
    if a.limit: n = a.limit
    t0 = time.time()
    with Pool(a.workers, initializer=init, initargs=(a.run, a.city, a.variant)) as pool:
        res = pool.map(job, range(n), chunksize=4)
    res.sort(key=lambda x: x[0])
    keys = res[0][1].keys()
    arrs = {k: np.vstack([r[1][k] for r in res]) for k in keys}
    traj = np.stack([r[2] for r in res]); fix = np.array([r[3] for r in res])
    P = np.load(ROOT / "work" / f"stock_{a.city}.npz", allow_pickle=True)
    tag = a.run + ("_test" if a.limit else "")
    np.savez_compressed(ROOT / "work" / f"curves_{tag}.npz", LEVELS=LEVELS, d=P["dep"][:n],
                        age=P["age"][:n], FIX=fix, core=traj, **arrs)
    S = arrs["S37"]; mono = sum(np.all(np.diff(S[i]) <= 1e-6) for i in range(n))
    print(f"{a.run}: n={n} {time.time()-t0:.0f}s | guard {fix.sum()} | monotone {mono}/{n} | "
          f"demand {arrs['E'][:, -1].sum():.0f} kWh | S37 med unmit {np.median(S[:, 0]):.1f} "
          f"full {np.median(S[:, -1]):.1f} | H38 med {np.median(arrs['H38'][:, 0]):.0f}h | "
          f"peak core {arrs['PK'][:, 0].max():.2f}", flush=True)
