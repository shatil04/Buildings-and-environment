#!/usr/bin/env bash
cd "$(dirname "$0")"
for spec in "HOU-A HOU base" "PHX PHX base" "CHI CHI base" "HOU-A-UQ HOU uq" "PHX-FAN PHX fan" "HOU-A-FAN HOU fan" "HOU-B HOU base"; do
  set -- $spec
  [ -f "work/curves_$1.npz" ] && { echo "skip $1"; continue; }
  python3 src/simulate.py --run "$1" --city "$2" --variant "$3" 2>&1 | grep -vE "Warning|valid_range"
done
echo "all runs finished"
