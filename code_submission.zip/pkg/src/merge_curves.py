"""
Stage 4. Merge dwelling-chunk response curves into a single array per episode
and attach the deprivation index derived from Federal Poverty Level.

    python src/merge_curves.py --episode A --n 400 --chunk 40
"""
import argparse
import numpy as np
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
FPL = ["0-100%", "100-150%", "150-200%", "200-300%", "300-400%", "400%+"]

ap = argparse.ArgumentParser()
ap.add_argument("--episode", required=True, choices=["A", "B"])
ap.add_argument("--n", type=int, default=400)
ap.add_argument("--chunk", type=int, default=40)
args = ap.parse_args()

keys = ["E", "DH", "S", "PK", "TMAX", "FIX"]
acc = {k: [] for k in keys}
for a in range(0, args.n, args.chunk):
    z = np.load(ROOT / "work" / f"curves_{args.episode}_{a}_{a + args.chunk}.npz")
    for k in keys:
        acc[k].append(z[k])
out = {k: (np.vstack(acc[k]) if k != "FIX" else np.concatenate(acc[k])) for k in keys}

P = np.load(ROOT / "work" / "stock_params.npz", allow_pickle=True)
rank = {f: i for i, f in enumerate(FPL)}
dep = np.array([1.0 - rank.get(f, 3) / 5.0 for f in P["fpl"]])

np.savez(ROOT / "work" / f"curves_episode_{args.episode}.npz",
         LEVELS=np.linspace(0, 1, 9), d=dep, age=P["age"], **out)

S, PK, E = out["S"], out["PK"], out["E"]
mono = sum(np.all(np.diff(S[i]) <= 1e-9) for i in range(len(S)))
print(f"episode {args.episode}: N={len(S)}  set-point guard fired on {out['FIX'].sum()}"
      f"  monotone {mono}/{len(S)}  unconstrained demand {E[:, -1].sum():.0f} kWh")
print(f"  unmitigated peak core {PK[:, 0].min():.2f}-{PK[:, 0].max():.2f} C"
      f"  median strain {np.median(S[:, 0]):.1f} C.h")
