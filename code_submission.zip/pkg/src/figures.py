import json
import numpy as np
import matplotlib
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
matplotlib.use("Agg"); import matplotlib.pyplot as plt
plt.rcParams.update({"font.size":8,"axes.linewidth":.7,"figure.dpi":300,
                     "font.family":"serif","axes.grid":True,"grid.alpha":.25,"grid.linewidth":.4})
J=json.load(open(ROOT / "out" / "summary.json")); C=["#4a5568","#b5523f","#2a7f6f"]
LB=["Energy-equity","Exposure-equity","Strain-equity"]; MK=["M1_ENERGY","M2_EXPOSURE","M3_STRAIN"]

# FIG 1 — forcing
F20=np.load(ROOT / "work" / "forcing_episode_A.npz"); F25=np.load(ROOT / "work" / "forcing_episode_B.npz")
fig,ax=plt.subplots(1,3,figsize=(7.2,2.2))
h=np.arange(72)
for F,lab,c in [(F20,"20-22 Aug 2023","#b5523f"),(F25,"25-27 Aug 2023","#4a5568")]:
    ax[0].plot(h,F["T_out"][24:],c=c,lw=1.1,label=lab)
    ax[1].plot(h,F["RH_out"][24:],c=c,lw=1.1)
    ax[2].plot(h,F["I_sol"][24:],c=c,lw=1.1)
syn=34.25-4.75*np.cos(((h%24)-5)/24*2*np.pi)+0.5*(h//24)
ax[0].plot(h,syn,c="#999",ls=":",lw=1.0,label="Idealised sinusoid (not used)")
for a,t in zip(ax,["Outdoor dry-bulb (°C)","Outdoor relative humidity (%)","Global horizontal irrad. (W m$^{-2}$)"]):
    a.set_xlabel("Hour of episode"); a.set_title(t,fontsize=8); a.set_xticks([0,24,48,72])
ax[0].legend(fontsize=6,frameon=False)
plt.tight_layout(); plt.savefig(ROOT / "out" / "fig1_forcing.pdf"); plt.close()

# FIG 2 — stock
P=np.load(ROOT / "work" / "stock_params.npz",allow_pickle=True)
FPL=['0-100%','100-150%','150-200%','200-300%','300-400%','400%+']
fig,ax=plt.subplots(1,3,figsize=(7.2,2.2))
ax[0].hist(P["UA"],bins=30,color="#4a5568",edgecolor="w",lw=.3)
ax[0].set_xlabel("Envelope conductance $UA$ (W K$^{-1}$)"); ax[0].set_ylabel("Dwellings")
ax[1].hist(P["age"],bins=24,color="#b5523f",edgecolor="w",lw=.3)
ax[1].set_xlabel("Age of most heat-vulnerable occupant (y)"); ax[1].set_ylabel("Dwellings")
o={f:i for i,f in enumerate(FPL)}; m=np.array([o.get(f,-1) for f in P["fpl"]])
ua_m=P["UA"]/np.maximum(P["Cap"]/120e3,1e-9)
bp=[ua_m[m==i] for i in range(6)]
ax[2].boxplot(bp,widths=.6,patch_artist=True,
  boxprops=dict(facecolor="#cbd5e0",lw=.6),medianprops=dict(color="#b5523f",lw=1.1),
  flierprops=dict(ms=1.5,alpha=.4),whiskerprops=dict(lw=.6),capprops=dict(lw=.6))
ax[2].set_xticklabels([f.replace("%","") for f in FPL],rotation=45,fontsize=6)
ax[2].set_xlabel("Federal Poverty Level (%)"); ax[2].set_ylabel("$UA$ per unit floor area")
plt.tight_layout(); plt.savefig(ROOT / "out" / "fig2_stock.pdf"); plt.close()

# FIG 3 — reordering scatter + strain bars (primary window)
A=J["episode_A"]; al={k:np.array(A["alloc"][k]) for k in MK}; st={k:np.array(A["strain"][k]) for k in MK}
d=np.array(A["dep"]); rng=np.random.default_rng(3); jit=(rng.random(len(d))-.5)*.32
fig,ax=plt.subplots(1,3,figsize=(7.2,2.4))
for i,mk in enumerate(MK[:2]):
    s=ax[i].scatter(al["M3_STRAIN"]+jit,al[mk]+jit,c=d,cmap="magma_r",s=13,lw=.25,edgecolor="k")
    ax[i].plot([-.5,8.5],[-.5,8.5],"k--",lw=.7)
    ax[i].set_xlabel("Cooling level, strain-equity"); ax[i].set_ylabel(f"Cooling level, {LB[i].lower()}")
    ax[i].set_title(r"$\rho$ = %.2f, migration %.0f%%"%(A["reo"][mk]["rho"],100*A["reo"][mk]["mig"]),fontsize=8)
cb=plt.colorbar(s,ax=ax[1],pad=.02); cb.set_label("Deprivation index",fontsize=6); cb.ax.tick_params(labelsize=6)
v=d>=np.quantile(d,.80); x=np.arange(3); w=.26
vals=[[st[k][v].mean() for k in MK],[np.median(st[k]) for k in MK],[st[k].max() for k in MK]]
for i,(lab,c) in enumerate(zip(LB,C)):
    ax[2].bar(x+(i-1)*w,[vals[j][i] for j in range(3)],w,label=lab,color=c,edgecolor="k",lw=.4)
ax[2].set_xticks(x); ax[2].set_xticklabels(["Deprived\nquintile","Median\ndwelling","Worst\ndwelling"],fontsize=7)
ax[2].set_ylabel(r"Strain $S_i$ (°C·h $>$ 37 °C)"); ax[2].legend(fontsize=6,frameon=False)
plt.tight_layout(); plt.savefig(ROOT / "out" / "fig3_reordering.pdf"); plt.close()

# FIG 4 — robustness heatmaps
fig,ax=plt.subplots(1,2,figsize=(7.2,2.6))
for p,(tag,tt) in enumerate([("episode_A","20-22 Aug"),("episode_B","25-27 Aug")]):
    sw=J[tag]["sweep"]; etas=[0.5,1.5,2.0,4.0]; bs=[0.35,0.45,0.60]
    M=np.zeros((4,3))
    for r in sw:
        i,j=etas.index(r["eta"]),bs.index(r["b"])
        best=min(r["M1_ENERGY"][0],r["M2_EXPOSURE"][0])
        M[i,j]=100*(best-r["M3_STRAIN"][0])/best
    im=ax[p].imshow(M,cmap="RdBu",vmin=-6,vmax=6,aspect="auto")
    for i in range(4):
        for j in range(3):
            ax[p].text(j,i,f"{M[i,j]:+.1f}",ha="center",va="center",fontsize=7,
                       color="k" if abs(M[i,j])<4 else "w")
    ax[p].set_xticks(range(3)); ax[p].set_xticklabels([f"{int(100*b)}%" for b in bs])
    ax[p].set_yticks(range(4)); ax[p].set_yticklabels(etas)
    ax[p].set_xlabel("Energy budget (fraction of unconstrained)"); ax[p].set_ylabel(r"Inequality aversion $\eta$")
    ax[p].set_title(f"{tt} 2023",fontsize=8); ax[p].grid(False)
cb=plt.colorbar(im,ax=ax,pad=.02); cb.set_label("Deprived-quintile strain reduction under M3 (%)",fontsize=6)
cb.ax.tick_params(labelsize=6)
plt.savefig(ROOT / "out" / "fig4_robustness.pdf", bbox_inches="tight"); plt.close()
print("figures written")
