"""
Stage 5. Exact allocation under three equity currencies.

Stock, budget, inequality-aversion parameter and solver are held fixed; only
the currency of the equity objective changes:

  M1 ENERGY   x_i = share of unconstrained cooling service delivered
  M2 EXPOSURE x_i = fraction of indoor degree-hours >26C averted
  M3 STRAIN   x_i = fraction of core-temperature excess >37C averted  (JOS-3)

Welfare (Atkinson / CES, equal weights so the metric is the ONLY difference):
  W = sum_i x_i^(1-eta) / (1-eta)      maximised s.t. sum_i E_i <= B

Solved exactly by dynamic programming over a discretised energy budget, so
that no interaction between optimiser quality and currency curvature can
confound the comparison.
"""
import argparse, itertools, json
import numpy as np
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
_ap = argparse.ArgumentParser()
_ap.add_argument("--episode", required=True, choices=["A", "B"])
_args = _ap.parse_args()
D = np.load(ROOT / "work" / f"curves_episode_{_args.episode}.npz", allow_pickle=True)
E, DH, S, PK = D["E"], D["DH"], D["S"], D["PK"]
d, age, LEVELS = D["d"], D["age"], D["LEVELS"]
N, L = E.shape
EPS = 1e-6
GRID = 0.5                                   # kWh discretisation

# ---- goods (all normalised to [0,1], higher = better served) ----------------
def goods(metric):
    if metric == "M1_ENERGY":
        base = E[:, -1:]
        g = E / np.maximum(base, EPS)
        g[base[:, 0] < 1e-9] = 1.0           # no AC -> nothing deliverable
        return g
    if metric == "M2_EXPOSURE":
        base = DH[:, :1]
        g = np.clip((base - DH) / np.maximum(base, EPS), 0, 1)
        g[base[:, 0] < 1e-9] = 1.0            # nothing to avert -> already served
        return g
    if metric == "M3_STRAIN":
        base = S[:, :1]
        g = np.clip((base - S) / np.maximum(base, EPS), 0, 1)
        g[base[:, 0] < 1e-9] = 1.0
        return g
    raise ValueError(metric)

def welfare_vals(x, eta):
    xc = np.clip(x, 1e-4, 1.0)
    if abs(eta - 1.0) < 1e-9:
        return np.log(xc)
    return xc ** (1 - eta) / (1 - eta)

def solve(metric, eta, budget_kwh):
    """Exact DP. Returns chosen level index per dwelling."""
    v = welfare_vals(goods(metric), eta)
    c = np.rint(E / GRID).astype(int)                 # integer cost per level
    B = int(round(budget_kwh / GRID))
    NEG = -1e18
    dp = np.full(B + 1, NEG); dp[0] = 0.0
    choice = np.zeros((N, B + 1), dtype=np.int8)
    for i in range(N):
        best = np.full(B + 1, NEG)
        bestj = np.zeros(B + 1, dtype=np.int8)
        for j in range(L):
            cj = c[i, j]
            if cj > B: continue
            cand = np.full(B + 1, NEG)
            cand[cj:] = dp[:B + 1 - cj] + v[i, j]
            upd = cand > best
            best[upd] = cand[upd]; bestj[upd] = j
        dp, choice[i] = best, bestj
    # backtrack from the best feasible budget
    b = int(np.argmax(dp))
    lev = np.zeros(N, dtype=int)
    for i in range(N - 1, -1, -1):
        j = int(choice[i, b]); lev[i] = j; b -= c[i, j]
    return lev

def spearman(a, b):
    ra = np.argsort(np.argsort(a)).astype(float)
    rb = np.argsort(np.argsort(b)).astype(float)
    ra -= ra.mean(); rb -= rb.mean()
    return float(ra @ rb / np.sqrt((ra @ ra) * (rb @ rb)))

def realised(lev):
    idx = (np.arange(N), lev)
    return dict(E=float(E[idx].sum()), peak=PK[idx], strain=S[idx], dh=DH[idx])

METRICS = ["M1_ENERGY", "M2_EXPOSURE", "M3_STRAIN"]
DANGER = 38.0                                  # core temperature danger threshold
FULL = E[:, -1].sum()

# ---------------------------------------------------------------- base case --
ETA, BFRAC = 2.0, 0.45
budget = BFRAC * FULL
print(f"Unconstrained demand {FULL:.1f} kWh | budget {budget:.1f} kWh ({BFRAC:.0%}) | eta={ETA}\n")

alloc, res = {}, {}
for m in METRICS:
    alloc[m] = solve(m, ETA, budget)
    res[m] = realised(alloc[m])

vuln = d >= np.quantile(d, 0.80)               # most-deprived quintile
print("=== BASE CASE: realised outcomes at identical energy budget ===")
print(f"{'metric':<12} {'kWh':>7} {'maxcore':>8} {'maxStrain':>10} {'vulnStrain':>11} {'medStrain':>10}")
for m in METRICS:
    r = res[m]
    print(f"{m:<12} {r['E']:7.1f} {r['peak'].max():8.2f} {r['strain'].max():10.2f} "
          f"{r['strain'][vuln].mean():11.2f} {np.median(r['strain']):10.2f}")

print("\n=== REORDERING vs M3_STRAIN ===")
for m in METRICS[:2]:
    rho = spearman(alloc[m], alloc["M3_STRAIN"])
    q_a = np.digitize(alloc[m], np.quantile(alloc[m], [.25, .5, .75]))
    q_b = np.digitize(alloc["M3_STRAIN"], np.quantile(alloc["M3_STRAIN"], [.25, .5, .75]))
    moved = float((q_a != q_b).mean())
    shift = float(np.abs(alloc[m] - alloc["M3_STRAIN"]).mean())
    print(f"{m:<12} spearman={rho:+.3f}  quartile-migration={moved:.1%}  mean|dLevel|={shift:.2f}")

# --------------------------------------------- energy penalty to match M3 ----
print("\n=== EXTRA ENERGY M1/M2 NEED TO MATCH M3 ON VULNERABLE-QUINTILE STRAIN ===")
target = res["M3_STRAIN"]["strain"][vuln].mean()
for m in METRICS[:2]:
    lo, hi, found = BFRAC, 1.00, None
    for _ in range(16):
        mid = 0.5 * (lo + hi)
        v = realised(solve(m, ETA, mid * FULL))["strain"][vuln].mean()
        if v <= target: hi, found = mid, mid
        else: lo = mid
    f = found if found else hi
    print(f"{m:<12} needs {f:.3f} x full demand (base {BFRAC:.2f}) -> +{(f/BFRAC-1)*100:.0f}% energy")

# ------------------------------------------------------------- robustness ----
print("\n=== ROBUSTNESS: dwellings above 38.0C core / max core temp ===")
print("cells = vulnerable-quintile mean strain (C.h) / max strain (C.h)")
print(f"{'eta':>5} {'budget':>7} " + " ".join(f"{m:>17}" for m in METRICS))
rows = []
for eta, bf in itertools.product([0.5, 1.5, 2.0, 4.0], [0.35, 0.45, 0.60]):
    line, rec = f"{eta:5.1f} {bf:7.0%} ", {"eta": eta, "budget": bf}
    for m in METRICS:
        r = realised(solve(m, eta, bf * FULL))
        vs, mx = r["strain"][vuln].mean(), r["strain"].max()
        line += f" {vs:7.2f} /{mx:8.2f}"
        rec[m] = [round(float(vs), 3), round(float(mx), 3)]
    rows.append(rec); print(line)

json.dump({"episode": _args.episode, "base": {m: {"levels": alloc[m].tolist(),
                        "peak": res[m]["peak"].tolist(),
                        "strain": res[m]["strain"].tolist()} for m in METRICS},
           "robust": rows, "d": d.tolist(), "age": age.tolist(), "full": float(FULL)},
          open(ROOT / "out" / f"results_episode_{_args.episode}.json", "w"))
print(f"\nsaved out/results_episode_{_args.episode}.json")
