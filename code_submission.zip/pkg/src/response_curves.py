"""
Stage 3. Coupled RC + JOS-3 simulation producing response curves.

For each dwelling and each discrete cooling-allocation level, returns delivered
energy, indoor exposure degree-hours and integrated physiological strain over
the analysed episode, with the spin-up day discarded.

Runs in dwelling chunks so that long jobs can be checkpointed:
    python src/response_curves.py --episode A --start 0 --end 40
"""
import argparse, time, warnings
import numpy as np
from pathlib import Path
from pythermalcomfort.models import JOS3

warnings.filterwarnings("ignore")
ROOT = Path(__file__).resolve().parents[1]

_ap = argparse.ArgumentParser()
_ap.add_argument("--episode", required=True, choices=["A", "B"])
_ap.add_argument("--start", type=int, required=True)
_ap.add_argument("--end", type=int, required=True)
_args = _ap.parse_args()

P = np.load(ROOT / "work" / "stock_params.npz", allow_pickle=True)
UA, Cap, Asol, Qint, Qmax = P["UA"], P["Cap"], P["Asol"], P["Qint"], P["Qmax"]
age, sex, height, weight, fat = P["age"], P["sex"], P["height"], P["weight"], P["fat"]
N = len(UA)

SPINUP = 24
HOURS = 96                     # 24 h spin-up + 72 h heatwave
# MEASURED FORCING: NOAA LCD Houston Hobby (KHOU), 20-22 Aug 2023 heat event.
# Daily Tmax/Tmin measured; diurnal shape fitted to observed hourly data of 10 Aug 2023.
# Dew point held constant within day; solar from TMYx EPW, same calendar days.
_F = np.load(ROOT / "work" / f"forcing_episode_{_args.episode}.npz")
T_out, RH_out, I_sol = _F["T_out"], _F["RH_out"], _F["I_sol"]
assert len(T_out) == HOURS

CLO, VAIR, PAR, DT = 0.35, 0.15, 1.1, 3600.0
SUBSTEP = 1200.0; PER_HOUR = int(3600 / SUBSTEP)
_REF = JOS3()
_CR = np.array(_REF.cr_set_point, dtype=float).copy()
_SK = np.array(_REF.sk_set_point, dtype=float).copy()
_TB = np.array(_REF.t_body, dtype=float).copy()
FIX = np.zeros(N, dtype=bool)

def sim_dwelling(i, frac):
    T = T_out[0] + 1.0; Tin = np.zeros(HOURS); q = 0.0; Tset = 27.0
    for k in range(HOURS):
        gain = UA[i] * (T_out[k] - T) + Asol[i] * I_sol[k] * 0.35 + Qint[i]
        q_av = Qmax[i] * frac
        # Ideal proportional thermostat with anti-windup. The earlier form used
        # max(0, gain), which caused discrete-time overshoot and non-monotone
        # response curves at high capacity. This drives T -> Tset exactly when
        # capacity allows and saturates otherwise.
        q_c = min(max(gain + Cap[i] * (T - Tset) / DT, 0.0), q_av)
        T += (gain - q_c) * DT / Cap[i]
        if k >= SPINUP:
            q += q_c * DT / 3.6e6
        Tin[k] = T
    return Tin, q

def psat(T): return 610.94 * np.exp(17.625 * T / (T + 243.04))

def sim_phys(i, Tin):
    m = JOS3(height=float(height[i]), weight=float(weight[i]), fat=float(fat[i]),
             age=int(age[i]), sex=str(sex[i]))
    sp0 = float(np.mean(m.cr_set_point))
    if (not np.isfinite(sp0)) or sp0 < 35.5:      # pythermalcomfort set-point guard
        m.cr_set_point, m.sk_set_point = _CR.copy(), _SK.copy()
        m.t_body = _TB.copy()          # NaN can poison body state at construction
        FIX[i] = True
    m.clo, m.v, m.par = CLO, VAIR, PAR
    rh_in = np.clip(RH_out * psat(T_out) / psat(Tin), 20, 95)
    core = np.zeros(HOURS)
    for k in range(HOURS):
        m.to = float(Tin[k]); m.rh = float(rh_in[k])
        m.simulate(times=PER_HOUR, dtime=SUBSTEP, output=False)
        core[k] = float(m.t_core[2])
    return core

LEVELS = np.linspace(0.0, 1.0, 9); L = len(LEVELS)
E = np.zeros((N, L)); DH = np.zeros((N, L)); S = np.zeros((N, L))
PK = np.zeros((N, L)); TMAX = np.zeros((N, L))
I0, I1 = _args.start, _args.end
t0 = time.time()
for i in range(I0, I1):
    for j, f in enumerate(LEVELS):
        Tin, kwh = sim_dwelling(i, f); core = sim_phys(i, Tin)
        Tv, Cv = Tin[SPINUP:], core[SPINUP:]        # discard spin-up
        E[i, j] = kwh
        DH[i, j] = np.sum(np.clip(Tv - 26.0, 0, None))
        S[i, j] = np.sum(np.clip(Cv - 37.0, 0, None))
        PK[i, j] = Cv.max(); TMAX[i, j] = Tv.max()
np.savez(ROOT / "work" / f"curves_{_args.episode}_{I0}_{I1}.npz", E=E[I0:I1], DH=DH[I0:I1], S=S[I0:I1],
         PK=PK[I0:I1], TMAX=TMAX[I0:I1], FIX=FIX[I0:I1], LEVELS=LEVELS)
print(f"episode {_args.episode} dwellings {I0}-{I1} done in {time.time()-t0:.1f}s")
