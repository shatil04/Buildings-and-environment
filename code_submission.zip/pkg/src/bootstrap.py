"""
Stage 5. Bootstrap over the dwelling stock to test stability of the reordering
and of the deprived-quintile effect.

    python src/bootstrap.py --episode A --resamples 200
"""
import argparse, sys
import numpy as np
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
_ap = argparse.ArgumentParser()
_ap.add_argument("--episode", required=True, choices=["A", "B"])
_ap.add_argument("--resamples", type=int, default=200)
_args = _ap.parse_args()

_src = (ROOT / "src" / "allocate.py").read_text().split("METRICS = [")[0]
_src = _src.replace("_args = _ap.parse_args()", "")
exec(_src.replace('_ap.add_argument("--episode", required=True, choices=["A", "B"])', ""))
GRID = 0.5
rng = np.random.default_rng(7)
NB = _args.resamples
rho1, rho2, gain1, gain2, pen = [], [], [], [], []
Eb, DHb, Sb, db = E.copy(), DH.copy(), S.copy(), d.copy()
for b in range(NB):
    idx = rng.integers(0, N, N)
    globals().update(dict(E=Eb[idx], DH=DHb[idx], S=Sb[idx], d=db[idx]))
    FULLb = E[:, -1].sum(); bud = 0.45 * FULLb
    a1, a2, a3 = solve("M1_ENERGY",2.0,bud), solve("M2_EXPOSURE",2.0,bud), solve("M3_STRAIN",2.0,bud)
    rho1.append(spearman(a1,a3)); rho2.append(spearman(a2,a3))
    v = d >= np.quantile(d,0.80); ar = np.arange(N)
    s1,s2,s3 = S[ar,a1][v].mean(), S[ar,a2][v].mean(), S[ar,a3][v].mean()
    gain1.append((s1-s3)/max(s1,1e-9)); gain2.append((s2-s3)/max(s2,1e-9))
globals().update(dict(E=Eb,DH=DHb,S=Sb,d=db))
def ci(x, lab):
    x=np.array(x); lo,hi=np.percentile(x,[2.5,97.5])
    print(f"{lab:44s} {x.mean():+7.3f}   95% CI [{lo:+.3f}, {hi:+.3f}]")
print(f"bootstrap resamples: {NB}\n")
ci(rho1,"Spearman(M1 alloc, M3 alloc)")
ci(rho2,"Spearman(M2 alloc, M3 alloc)")
ci(gain1,"vuln-strain reduction, M3 vs M1 (fraction)")
ci(gain2,"vuln-strain reduction, M3 vs M2 (fraction)")
print(f"\nP(M3 strictly better than M1 for vulnerable): {np.mean(np.array(gain1)>0):.0%}")
print(f"P(M3 strictly better than M2 for vulnerable): {np.mean(np.array(gain2)>0):.0%}")
