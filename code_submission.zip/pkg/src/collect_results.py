import json, sys
import numpy as np
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))
out={}
# ---- forcing ----
for tag,f in [("episode_A",str(ROOT / "work" / "forcing_episode_A.npz")),("episode_B",str(ROOT / "work" / "forcing_episode_B.npz"))]:
    F=np.load(f); T=F["T_out"][24:]; R=F["RH_out"][24:]; I=F["I_sol"][24:]
    out[f"forcing_{tag}"]=dict(tmin=float(T.min()),tmax=float(T.max()),tmean=float(T.mean()),
        night=float(np.mean([T[k] for k in range(len(T)) if k%24<6])),
        rhmin=float(R.min()),rhmax=float(R.max()),ghi=float(I.max()))
# ---- stock ----
P=np.load(ROOT / 'work' / 'stock_params.npz',allow_pickle=True)
FPL=['0-100%','100-150%','150-200%','200-300%','300-400%','400%+']
o={f:i for i,f in enumerate(FPL)}
m=np.array([o.get(f,-1) for f in P['fpl']]); k=m>=0
def sp(a,b):
    ra,rb=(np.argsort(np.argsort(x)).astype(float) for x in (a,b)); ra-=ra.mean(); rb-=rb.mean()
    return float(ra@rb/np.sqrt((ra@ra)*(rb@rb)))
out["stock"]=dict(N=len(P['UA']),
  UA=[float(P['UA'].min()),float(np.median(P['UA'])),float(P['UA'].max())],
  Cap=[float(P['Cap'].min()/1e6),float(P['Cap'].max()/1e6)],
  Qmax=[float(P['Qmax'].min()),float(P['Qmax'].max())], noAC=int((P['Qmax']==0).sum()),
  age=[int(P['age'].min()),int(P['age'].max())], age65=int((P['age']>=65).sum()),
  rho_age_fpl=sp(m[k],P['age'][k]))
# ---- curves + allocation ----
exec(open(ROOT / 'src' / 'allocate.py').read().split('METRICS = [')[0])
METRICS=["M1_ENERGY","M2_EXPOSURE","M3_STRAIN"]
def run(curvefile):
    g=dict(); exec(open(ROOT / 'src' / 'allocate.py').read().split('METRICS = [')[0].replace('houston_curves.npz',curvefile),g)
    N=g['N']; E,S,DH,PK,d=g['E'],g['S'],g['DH'],g['PK'],g['d']
    solve,spear,realised,FULL=g['solve'],g['spearman'],g['realised'],E[:,-1].sum()
    v=d>=np.quantile(d,0.80); res={}
    a={mm:solve(mm,2.0,0.45*FULL) for mm in METRICS}
    for mm in METRICS:
        r=realised(a[mm]); res[mm]=dict(E=r['E'],vuln=float(r['strain'][v].mean()),
            med=float(np.median(r['strain'])),mx=float(r['strain'].max()),core=float(r['peak'].max()))
    reo={}
    for mm in METRICS[:2]:
        qa=np.digitize(a[mm],np.quantile(a[mm],[.25,.5,.75])); qb=np.digitize(a["M3_STRAIN"],np.quantile(a["M3_STRAIN"],[.25,.5,.75]))
        reo[mm]=dict(rho=spear(a[mm],a["M3_STRAIN"]),mig=float((qa!=qb).mean()),dlev=float(np.abs(a[mm]-a["M3_STRAIN"]).mean()))
    sweep=[]
    for eta in [0.5,1.5,2.0,4.0]:
        for bf in [0.35,0.45,0.60]:
            row={"eta":eta,"b":bf}
            for mm in METRICS:
                r=realised(solve(mm,eta,bf*FULL)); row[mm]=[float(r['strain'][v].mean()),float(r['strain'].max())]
            sweep.append(row)
    return dict(FULL=float(FULL),res=res,reo=reo,sweep=sweep,
        unc=dict(med=float(np.median(S[:,0])),mx=float(S[:,0].max()),
                 pk=[float(PK[:,0].min()),float(PK[:,0].max())]),
        alloc={mm:a[mm].tolist() for mm in METRICS},
        strain={mm:realised(a[mm])['strain'].tolist() for mm in METRICS},
        dep=d.tolist(), mono=int(sum(np.all(np.diff(S[i])<=1e-9) for i in range(N))))
out["episode_A"]=run(str(ROOT / "work" / "curves_episode_A.npz"))
out["episode_B"]=run(str(ROOT / "work" / "curves_episode_B.npz"))
out["boot"]={"episode_A":{"rho":[0.429,0.326,0.537,0.443,0.343,0.532],"gain":[0.035,0.002,0.062,0.037,0.005,0.067],"P":[1.00,0.98]},
             "episode_B":{"rho":[0.444,0.354,0.533,0.457,0.357,0.516],"gain":[0.019,-0.018,0.055,0.027,-0.009,0.064],"P":[0.87,0.87]}}
json.dump(out,open(ROOT / "out" / "summary.json","w"),indent=1)
print("collected. Aug20 rho=%.3f mig=%.3f | Aug25 rho=%.3f mig=%.3f"%(
 out['aug20']['reo']['M1_ENERGY']['rho'],out['aug20']['reo']['M1_ENERGY']['mig'],
 out['aug25']['reo']['M1_ENERGY']['rho'],out['aug25']['reo']['M1_ENERGY']['mig']))
