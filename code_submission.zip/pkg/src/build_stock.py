"""
Stage 1. Map sampled stock characteristics to RC thermal-model parameters.

Conservative design choice: occupant age is drawn INDEPENDENTLY of dwelling
characteristics. ResStock provides household size, not age, so any age-deprivation
coupling would be assumed rather than measured. Assuming independence makes the
divergence test HARDER to pass, which is the correct direction for a kill test.
"""
import json, re, sys, numpy as np
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from resstock_sampler import sample

N = 400
SEED = 101
rng = np.random.default_rng(SEED)

harris = json.load(open(ROOT / "data" / "houston_county_puma_weights.json"))
T = ["Vintage", "Geometry Building Type RECS", "Geometry Floor Area", "Insulation Wall",
     "Insulation Ceiling", "Windows", "Infiltration", "HVAC Cooling Type",
     "HVAC Cooling Efficiency", "Federal Poverty Level", "Occupants", "Tenure",
     "Geometry Stories", "Geometry Wall Type"]
recs, _ = sample(N, T, fixed={"ASHRAE IECC Climate Zone 2004": "2A",
                              "County and PUMA": harris}, seed=SEED)

# ---------------------------------------------------------------- parsers ---
def rval(s):
    m = re.search(r"R-(\d+)", s)
    if m: return float(m.group(1))
    return 0.0 if ("Uninsulated" in s or s == "None") else 0.0

def ach50(s):
    m = re.search(r"(\d+)\s*ACH50", s)
    return float(m.group(1)) if m else 15.0

def sqft(s):
    n = re.findall(r"\d+", s.replace("+", ""))
    if not n: return 1500.0
    return float(n[0]) if len(n) == 1 else float(np.mean([float(x) for x in n]))

def stories(s):
    m = re.match(r"(\d+)", s)
    return float(m.group(1)) if m else 1.0

def winq(s):
    if s == "Void": return 0.0
    return ({"Single": 0., "Double": 1., "Triple": 2.}[s.split(",")[0].strip()]
            + ("Low-E" in s) + ("Non-metal" in s) + 0.5 * ("Storm" in s))

def n_occ(s):
    m = re.match(r"(\d+)", s)
    return max(1, int(m.group(1))) if m else 2

R_IP2SI = 0.1761
CAP_PER_M2 = {"Brick": 250e3, "Concrete": 300e3, "Steel Frame": 150e3,
              "Wood Frame": 120e3, "Wood Stud": 120e3}

UA, Cap, Asol, Qint, Qmax = (np.zeros(N) for _ in range(5))
age = np.zeros(N, dtype=int); sex = np.empty(N, dtype=object)
fpl = np.empty(N, dtype=object); meta = []

# US adult age distribution; the heat-vulnerable occupant is the oldest adult
BINS = [(18, 24), (25, 44), (45, 64), (65, 79), (80, 90)]
PROB = np.array([0.12, 0.34, 0.32, 0.16, 0.06])

for i, r in enumerate(recs):
    A_f = sqft(r["Geometry Floor Area"]) * 0.0929           # m2 conditioned
    st = stories(r["Geometry Stories"])
    foot = A_f / st
    perim = 4 * np.sqrt(max(foot, 20.0))
    A_wall = perim * 2.7 * st
    A_win = 0.15 * A_wall
    A_wall_net = A_wall - A_win
    A_ceil = foot

    U_wall = 1.0 / max((rval(r["Insulation Wall"]) + 5.0) * R_IP2SI, 0.10)
    U_ceil = 1.0 / max((rval(r["Insulation Ceiling"]) + 4.0) * R_IP2SI, 0.10)
    wq = winq(r["Windows"])
    U_win = max(5.9 - 1.4 * wq, 1.4)
    SHGC = max(0.70 - 0.12 * wq, 0.25)

    V = A_f * 2.7
    ach_nat = ach50(r["Infiltration"]) / 17.0
    UA_inf = ach_nat * V * 1200.0 / 3600.0

    UA[i] = U_wall * A_wall_net + U_ceil * A_ceil + U_win * A_win + UA_inf
    Cap[i] = A_f * CAP_PER_M2.get(r["Geometry Wall Type"], 120e3)
    Asol[i] = A_win * SHGC * 0.5
    n = n_occ(r["Occupants"])
    Qint[i] = 80.0 + 60.0 * n

    design = UA[i] * (40.0 - 27.0) + Asol[i] * 880 * 0.35 * 0.6 + Qint[i]
    ct = r["HVAC Cooling Type"]
    if ct in ("Central AC", "Ducted Heat Pump", "Non-Ducted Heat Pump"):
        Qmax[i] = min(design * 1.05, 21000.0)   # cap at 6 tons
    elif ct in ("Room AC", "Evaporative or Swamp Cooler"):
        Qmax[i] = min(design * 1.05, 3500.0)
    else:
        Qmax[i] = 0.0

    n_ad = min(max(n, 1), 4)
    ages = []
    for _ in range(n_ad):
        lo, hi = BINS[rng.choice(len(BINS), p=PROB)]
        ages.append(rng.integers(lo, hi + 1))
    age[i] = int(max(ages))
    sex[i] = "male" if rng.random() < 0.5 else "female"
    fpl[i] = r["Federal Poverty Level"]
    meta.append({k: r[k] for k in T})

# body composition from age/sex (population means)
height = np.where(sex == "male", 1.75, 1.62) + rng.normal(0, 0.06, N)
weight = np.where(sex == "male", 86, 74) + rng.normal(0, 12, N)
fat = np.clip(np.where(sex == "male", 24, 34) + rng.normal(0, 4, N), 10, 45)

np.savez(ROOT / "work" / "stock_params.npz", UA=UA, Cap=Cap, Asol=Asol, Qint=Qint,
         Qmax=Qmax, age=age, sex=np.array([str(s) for s in sex]), height=height,
         weight=weight, fat=fat, fpl=np.array([str(f) for f in fpl]))
json.dump(meta, open(ROOT / "work" / "stock_metadata.json", "w"))

print(f"N={N} Houston CZ-2A dwellings mapped")
print(f"  UA        {UA.min():7.0f} - {UA.max():7.0f} W/K   (median {np.median(UA):.0f})")
print(f"  Cap       {Cap.min()/1e6:7.1f} - {Cap.max()/1e6:7.1f} MJ/K")
print(f"  Asol      {Asol.min():7.2f} - {Asol.max():7.2f} m2")
print(f"  Qmax      {Qmax.min():7.0f} - {Qmax.max():7.0f} W  (no cooling: {(Qmax==0).sum()})")
print(f"  age       {age.min():7d} - {age.max():7d}      (65+: {(age>=65).sum()})")
o = {f: i for i, f in enumerate(['0-100%','100-150%','150-200%','200-300%','300-400%','400%+'])}
m = np.array([o.get(f, -1) for f in fpl]); k = m >= 0
def sp(a, b):
    ra, rb = (np.argsort(np.argsort(x)).astype(float) for x in (a, b))
    ra -= ra.mean(); rb -= rb.mean()
    return ra @ rb / np.sqrt((ra @ ra) * (rb @ rb))
print(f"\n  Spearman(FPL rank, UA per m2)  = {sp(m[k], (UA/(Cap/120e3))[k]):+.3f}")
print(f"  Spearman(FPL rank, age)        = {sp(m[k], age[k]):+.3f}  (independent by design)")
