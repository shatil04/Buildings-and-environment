"""
Stage 2. Construct hourly meteorological forcing for the analysed heat episodes.

Temperature and moisture are measured. Daily maxima, minima and mean dew point
are taken from the official NOAA Local Climatological Data daily summary for
Houston Hobby (KHOU, WBAN 12918), August 2023. The intra-day shape is fitted to
the single complete day of published hourly observations (10 August 2023).
Global horizontal irradiance is taken from the TMYx typical-year EPW file for
the same calendar days.

Each episode is written with a leading 24-hour spin-up day that is discarded
from all reported metrics downstream.

Usage:
    python src/build_forcing.py --epw data/houston_tmyx.epw
"""
import argparse
import numpy as np
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

# ---------------------------------------------------------------------------
# NOAA LCD daily summary, KHOU, August 2023.
# columns: day, Tmax(F), Tmin(F), Tavg(F), mean RH(%), mean dew point(F),
#          mean wet bulb(F)
# ---------------------------------------------------------------------------
DAILY = np.array([
    (1, 101, 82, 92, 63, 74, 79), (2, 101, 79, 90, 63, 73, 78),
    (3,  99, 81, 90, 67, 75, 79), (4, 101, 81, 91, 65, 75, 79),
    (5, 101, 80, 91, 65, 75, 79), (6, 101, 81, 91, 65, 75, 79),
    (7, 102, 81, 92, 68, 76, 80), (8, 100, 81, 91, 67, 76, 79),
    (9, 101, 81, 91, 67, 76, 80), (10, 102, 81, 92, 67, 76, 80),
    (11, 102, 82, 92, 68, 77, 80), (12, 102, 83, 93, 68, 77, 81),
    (13, 102, 80, 91, 69, 76, 80), (14, 103, 79, 91, 66, 76, 79),
    (15, 104, 83, 94, 58, 74, 79), (16, 100, 80, 90, 44, 63, 72),
    (17, 103, 78, 91, 64, 72, 77), (18, 102, 79, 91, 65, 73, 78),
    (19, 103, 79, 91, 65, 75, 79), (20, 107, 82, 95, 60, 74, 79),
    (21, 100, 82, 91, 63, 75, 80), (22,  97, 84, 91, 67, 76, 80),
    (23, 101, 81, 91, 57, 72, 78), (24, 107, 82, 95, 52, 71, 78),
    (25, 101, 81, 91, 55, 72, 77), (26, 104, 80, 92, 58, 71, 77),
    (27, 109, 80, 95, 53, 69, 76), (28, 100, 80, 90, 55, 71, 76),
    (29,  98, 81, 90, 46, 65, 73), (30, 101, 78, 90, 39, 60, 70),
    (31, 100, 77, 89, 42, 61, 71),
], dtype=float)

# Observed hourly dry-bulb, 10 August 2023, 00:53 to 23:53 LST, degrees C.
OBS_HOURLY = np.array([
    28.9, 28.3, 28.3, 27.8, 27.8, 27.2, 28.3, 31.1, 31.7, 33.3, 36.1, 37.2,
    37.2, 38.9, 38.3, 37.2, 36.7, 34.4, 32.8, 31.1, 30.0, 29.4, 28.9, 28.9,
])

EPISODES = {"A": 20, "B": 25}       # first analysed day of each episode
NDAYS = 3
SPINUP_DAYS = 1


def f_to_c(f):
    return (f - 32.0) * 5.0 / 9.0


def p_sat(t_c):
    """Magnus saturation vapour pressure, Pa."""
    return 610.94 * np.exp(17.625 * t_c / (t_c + 243.04))


OBS_DAY = 10          # day of month of the observed hourly series


def diurnal_shape():
    """
    Normalised intra-day shape from the observed hourly day, scaled by that
    day's official daily extremes rather than by the hourly series' own range,
    so that the shape is defined consistently with the daily record it is
    applied to.
    """
    i = OBS_DAY - 1
    hi, lo = f_to_c(DAILY[i, 1]), f_to_c(DAILY[i, 2])
    return (OBS_HOURLY - lo) / (hi - lo)


def read_epw_ghi(epw_path):
    """Return arrays of month, day and global horizontal irradiance."""
    rows = [ln.split(",") for ln in open(epw_path)
            if ln[:1].isdigit() and len(ln.split(",")) > 30]
    mo = np.array([int(r[1]) for r in rows])
    dy = np.array([int(r[2]) for r in rows])
    ghi = np.array([float(r[13]) for r in rows])
    return mo, dy, ghi


def build(start_day, mo, dy, ghi):
    day = DAILY[:, 0]
    t_max = f_to_c(DAILY[:, 1])
    t_min = f_to_c(DAILY[:, 2])
    t_dew = f_to_c(DAILY[:, 5])
    shape = diurnal_shape()

    idx = [int(start_day) - 1 - SPINUP_DAYS + k
           for k in range(NDAYS + SPINUP_DAYS)]

    t_out = np.concatenate([t_min[i] + shape * (t_max[i] - t_min[i]) for i in idx])
    dew = np.concatenate([np.full(24, t_dew[i]) for i in idx])
    rh = np.clip(100.0 * p_sat(dew) / p_sat(t_out), 5.0, 100.0)
    solar = np.concatenate([ghi[(mo == 8) & (dy == int(day[i]))] for i in idx])
    return t_out, rh, solar, dew


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--epw", required=True,
                    help="TMYx EPW file for the reference station")
    args = ap.parse_args()

    mo, dy, ghi = read_epw_ghi(args.epw)
    (ROOT / "work").mkdir(exist_ok=True)

    for tag, start in EPISODES.items():
        t_out, rh, solar, dew = build(start, mo, dy, ghi)
        out = ROOT / "work" / f"forcing_episode_{tag}.npz"
        np.savez(out, T_out=t_out, RH_out=rh, I_sol=solar, dewpt=dew,
                 start_day=start, spinup_hours=24 * SPINUP_DAYS)
        v = t_out[24:]
        night = np.mean([v[k] for k in range(len(v)) if k % 24 < 6])
        print(f"episode {tag} (Aug {start}-{start + NDAYS - 1}): "
              f"T {v.min():.1f}-{v.max():.1f} C, mean {v.mean():.1f} C, "
              f"night mean {night:.1f} C, peak GHI {solar[24:].max():.0f} W/m2 "
              f"-> {out.name}")


if __name__ == "__main__":
    main()
