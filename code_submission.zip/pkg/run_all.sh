#!/usr/bin/env bash
# Full reproduction pipeline. Total runtime is dominated by stage 3
# (approximately 26 min per episode on one CPU core).
set -euo pipefail
cd "$(dirname "$0")"
N=${N:-400}
CHUNK=${CHUNK:-40}

echo "== Stage 1: sample stock and map to RC parameters =="
python src/build_stock.py

echo "== Stage 2: build measured forcing =="
python src/build_forcing.py --epw data/houston_tmyx.epw

for EP in A B; do
  echo "== Stage 3: response curves, episode $EP =="
  for ((a=0; a<N; a+=CHUNK)); do
    python src/response_curves.py --episode "$EP" --start "$a" --end "$((a+CHUNK))"
  done
  echo "== Stage 4: merge curves, episode $EP =="
  python src/merge_curves.py --episode "$EP" --n "$N" --chunk "$CHUNK"
  echo "== Stage 5: allocation, episode $EP =="
  python src/allocate.py --episode "$EP"
  echo "== Stage 5b: bootstrap, episode $EP =="
  python src/bootstrap.py --episode "$EP" --resamples 200
done

echo "== Stage 6: collect results and draw figures =="
python src/collect_results.py
python src/figures.py
echo "Done. Outputs in out/."
