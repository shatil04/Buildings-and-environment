#!/usr/bin/env bash
# Download the two external inputs that are not redistributed with this archive.
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p data

echo "1/2  ResStock national housing characteristics"
if [ ! -d data/housing_characteristics ]; then
  curl -sSL https://codeload.github.com/NREL/resstock/tar.gz/refs/heads/develop \
    | tar -xz --wildcards "*/project_national/housing_characteristics/*.tsv"
  mv resstock-develop/project_national/housing_characteristics data/
  rm -rf resstock-develop
fi
echo "     $(ls data/housing_characteristics/*.tsv | wc -l) characteristic tables"

echo "2/2  TMYx weather file"
echo "     Download the EPW for the reference station from climate.onebuilding.org"
echo "     and place it at data/houston_tmyx.epw (not redistributed: see LICENCE terms)."
