# Reproduction package

Code accompanying the manuscript *Fairness in cooling allocation is
under-determined: equity metrics reorder protection for half of a housing stock
without advantaging the deprived*.

The package reproduces every number, table and figure in the paper from
publicly available inputs.

---

## 1. Requirements

Python 3.10 or later.

```bash
pip install -r requirements.txt
```

`pythermalcomfort` is pinned to **4.4.2**, the version in which the
thermoregulation set-point defect documented in the paper was characterised.
The guard implemented in `src/response_curves.py` detects and corrects the
defect; see Section 6.1 and Appendix B of the manuscript. If a later release
fixes the underlying issue, the guard becomes inert but remains safe to run.

Roughly 2 GB of RAM and 1 GB of disk are sufficient. The pipeline is
single-threaded; total runtime is approximately 55 minutes on one modern CPU
core, dominated by the thermoregulation integration.

---

## 2. External inputs

Two inputs are not redistributed here and must be fetched once:

```bash
./fetch_inputs.sh
```

| Input | Source | Placed at |
|---|---|---|
| ResStock national housing characteristics (160 conditional probability tables) | NREL ResStock repository, `develop` branch | `data/housing_characteristics/` |
| TMYx typical-year weather file for the reference station | climate.onebuilding.org | `data/houston_tmyx.epw` |

The script downloads the first automatically. The weather file must be
downloaded manually because its licence does not permit redistribution.

The measured meteorological record (NOAA Local Climatological Data daily
summary and the single published hourly day) is embedded directly in
`src/build_forcing.py`, so no download is required for the temperature and
moisture forcing. Only irradiance is read from the EPW.

`data/houston_county_puma_weights.json` ships with the package and contains the
38 county–PUMA cells of the study county with their conditional probability
weights within climate zone 2A.

---

## 3. Running

```bash
./run_all.sh
```

Or stage by stage:

```bash
python src/build_stock.py                                   # 1  sample + map stock
python src/build_forcing.py --epw data/houston_tmyx.epw     # 2  measured forcing

# 3  response curves, run in dwelling chunks (checkpointed)
python src/response_curves.py --episode A --start 0 --end 40
#    ... repeat to --start 360 --end 400, then likewise for episode B

python src/merge_curves.py --episode A --n 400 --chunk 40   # 4  merge chunks
python src/allocate.py     --episode A                      # 5  exact allocation
python src/bootstrap.py    --episode A --resamples 200      # 5b uncertainty

python src/collect_results.py                               # 6  assemble numbers
python src/figures.py                                       #    draw figures
```

Episode A is 20–22 August 2023 (highest overnight minima); episode B is
25–27 August 2023 (contains the record daily maximum).

---

## 4. Layout

```
src/resstock_sampler.py    generic dependency-graph sampler over the
                           conditional probability tables
src/build_stock.py         maps sampled characteristics to 1R1C parameters
                           (UA, C, A_sol, Qmax) and assigns occupants
src/build_forcing.py       constructs hourly forcing from the measured daily
                           record and the fitted diurnal shape
src/response_curves.py     coupled RC + JOS-3 simulation; emits E, D, S per
                           dwelling per allocation level
src/merge_curves.py        merges chunks, attaches the deprivation index
src/allocate.py            exact dynamic-programming allocation under the
                           three equity currencies, plus the eta x budget sweep
src/bootstrap.py           stock resampling for uncertainty intervals
src/collect_results.py     assembles every reported number into out/summary.json
src/figures.py             produces figures 2-5 of the manuscript

data/                      inputs
work/                      intermediates (regenerable)
out/                       results and figures
```

---

## 5. Reproducibility notes

**Random seeds.** The stock draw is seeded (`SEED = 101` in
`src/build_stock.py`) and the bootstrap is seeded independently. Re-running
without changing seeds reproduces the published stock exactly.

**Chunking.** Stage 3 is split into dwelling chunks purely so that long runs can
be interrupted and resumed. Chunk size does not affect results; `--chunk 400`
in a single call gives identical output.

**Timestep.** The thermoregulation model is integrated at 1200 s. Appendix C
of the manuscript reports the timestep-independence check; do not increase it
above 1200 s, at which point the integration drifts and then fails.

**Thermostat formulation.** `src/response_curves.py` implements an ideal
proportional thermostat with anti-windup. A naive formulation using
`max(0, gain)` produces a discrete-time limit cycle and non-monotone response
curves; see Section 6.2 of the manuscript. `src/merge_curves.py` reports the
monotonicity count as a check — expect 397 or more out of 400.

**Budget discretisation.** The dynamic program uses a 0.5 kWh budget grid
(`GRID` in `src/allocate.py`). Halving it changes no reported statistic in the
third significant figure but roughly doubles runtime.

---

## 6. Expected output

`out/summary.json` collects every number cited in the manuscript.
`out/results_episode_{A,B}.json` hold the per-episode base case, allocation
vectors and full sweep. Figures are written to `out/` as PDF.

Headline values, for verification:

| Quantity | Episode A | Episode B |
|---|---|---|
| Spearman, energy vs strain | 0.424 | 0.474 |
| Quartile migration | 55.5% | 54.0% |
| Median strain, M1 → M3 (°C·h) | 22.84 → 19.16 | 21.72 → 17.05 |
| Energy-equivalent penalty | +15% | +13% |
| Set-point guard activations | 31 / 400 | 31 / 400 |

---

## 7. Licence

Released under the MIT Licence. The external inputs retain the licences of their
respective providers.
